const dom = require("./xmldom/index.js").DOMParser;
const parse5 = require("./parse5.min.js");

module.exports = function (html) {
    const doc = parse5.parseFragment(html);
    const document = new dom().parseFromString(
        parse5.serialize(doc),
        "text/html"
    );
    return document;
};
