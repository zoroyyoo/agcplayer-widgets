const { M3uParser } = require('./lib/m3u/index.js')
const { success, error } = require('./lib/response')
const { writeFileSync } = require('./lib/debug.js')

let sourceList = []

const direction = {
    horizontal: "horizontal",
    vertical: "vertical",
};

async function home() {
    try {
        sourceList= await getSourceData();

        const result = sourceList.map((item, i) => ({
            type_id: i,
            type_name: item.type_name,
            vod_list: item.vod_list.slice(0, 6)
        }))

        return success(result);
    } catch (e) {
        return error(e.message);
    }
}

async function detail(params) {
    try {
        const { vod_id} = params;
        let source ;
        for(let i =0, len = sourceList.length; i< len ; i++) {
            const item = sourceList[i]
            const vod = item.vod_list.find(sub=> sub.vod_id === vod_id)
            if(vod) {
                source = vod;
                break;
            }
        }
        if(!source) {
            throw new Error('not found')
        }
        const result = {
            ...source,
            "vod_sources": [
                {
                    "vod_play_list": {
                        "url_count": 1,
                        "urls": [
                            {
                                "url": params.vod_id
                            },
                        ]
                    }
                }
            ],
        }
        return success(result)
    } catch(e) {
        return error(e.message)
    }
   
}

async function play({ url }) {
    return Promise.resolve(success(url))
}

async function search(keyword, page = 1) {
    try {
        let vodList = []
        if(page === 1) {
            sourceList.forEach(source => {
                const filterList = source.vod_list.filter(vod => vod.vod_name.includes(keyword.trim()))
                vodList = vodList.concat(filterList)
            })
        }

        return success({
            page,
            pages: 1,
            list: vodList
        })
    } catch (e) {
        return error(e.message);
    }
}

async function list(type_id, page = 1) {
    try {

        let vodList = []
        if(page === 1) {
            vodList = sourceList[type_id]?.vod_list ?? []
        }
        return success({
            page,
            pages: 1,
            list: vodList
        })
    } catch (e) {
        return error(e.message);
    }
}

async function getSourceData() {
    try {
        const response = await fetch('https://tv.iill.top/m3u/Gather', {
            headers: {
                'User-Agent': 'VLC/3.0.11.1 LibVLC/3.0.11.1',
            }
        })
        const text = await response.text();
        writeFileSync('m3u.txt', text)
        const json = await M3uParser.parse(text);

        // group-title 分组
        const groupMap = {}

        // 没有父分类的频道
        const noRootMedias = []
        json.medias.forEach(media => {
            // 过滤没有播放地址的频道
            if (!media.location) return;
            const groupTitle = (media?.attributes?.["group-title"] ?? "").trim()
            // media.kodiProps = Object.fromEntries(media.kodiProps)

            const vod_id = media.location;
            const vod_name = media.name || media.attributes?.['tvg-name']
            const vod_pic = media.attributes?.['tvg-logo']
            // const kodiProps = media?.kodiProps
            if(vod_id.endsWith('.mp4') || vod_pic?.includes('温馨提示.png')) return;

            if (!groupTitle) {
                noRootMedias.push({
                    vod_id,
                    vod_name,
                    vod_pic,
                    direction: direction.horizontal
                    // kodiProps
                })
            } else {
                if (!groupMap[groupTitle]) {
                    groupMap[groupTitle] = []
                }
                groupMap[groupTitle].push({
                    vod_id,
                    vod_name,
                    vod_pic,
                    direction: direction.horizontal
                    // kodiProps
                })
            }
        })

        let channels = []
        for (let [key, value] of Object.entries(groupMap)) {
            channels.push({
                type_name: key,
                vod_list: value,
            })
        }

        channels = channels.sort((a, b) => {
            const nameA = a.type_name;
            const nameB = b.type_name;
            return nameA.localeCompare(nameB);
        })

        if (noRootMedias.length > 0) {
            const undefineGroupName = '未知分类'
            let idx = 1
            channels.push({
                type_name: undefineGroupName,
                vod_list: noRootMedias.sort((a, b) => {
                    const nameA = a.vod_name ? a.vod_name.trim() : '';
                    const nameB = b.vod_name ? b.vod_name.trim() : '';
                    if (!a.vod_name && b.vod_name) return 1;
                    if (a.vod_name && !b.vod_name) return -1;

                    return nameA.localeCompare(nameB);
                }).map(media => ({
                    ...media,
                    vod_name: media.vod_name || `频道_${idx++}`
                }))
            })
        }

        return channels
    } catch (e) {
        throw new Error(`获取数据源失败, ${e.message}`)
    }
}

module.exports.home = home;
module.exports.play = play;
module.exports.detail = detail;
module.exports.search = search;
module.exports.list = list;