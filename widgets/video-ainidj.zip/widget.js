const { success, error } = require('./lib/response');
const { request } = require('./lib/request.js')
const select = require("./lib/xpath.js");
const dom = require("./lib/xmldom/index.js").DOMParser;
const parse5 = require("./lib/parse5.min.js");
const { writeFileSync, readFileSync  } = require('./lib/debug.js')
const { unescapeEntity } = require('./lib/index.js')

const host = 'https://ainidj.com'

const direction = {
    horizontal: "horizontal",
    vertical: "vertical",
};

/**
 * 获取首页分类
 * @returns 
 */
async function home() {
    try {
        const response = await request(host)
        const notStandardHtml = await response.text()
        writeFileSync('home.html', notStandardHtml)
        // const notStandardHtml = readFileSync('home.html')
         // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
         const doc5 = parse5.parseFragment(notStandardHtml);
         const html = parse5.serialize(doc5);
 
         const document = new dom().parseFromString(html, "text/html");

         const result = []

         const $main =  select(
            document,
            "//main[contains(@id, 'index-main')]/div[contains(@class, 'content')]"
        )[0]

        if(!$main) throw new Error('解析失败， content not Found')

        const $modules = select($main, "./div[contains(@class, 'module')]");
        if($modules?.length) {
            $modules.forEach(($module, i) => {
                const type_name = select($module, ".//h2[contains(@class, 'module-title')]/text()")?.toString()?.trim();
                const typeStr = select($module, ".//div[contains(@class, 'module-heading')]/a[contains(@class, 'more')]/@href")[0]?.value?.trim()
                if(!type_name) return;
                let type_id;
                if(typeStr) {
                    const matchVal = typeStr.match(/\/([\w-]+)\.html$/);
                    if (matchVal) {
                        type_id = matchVal[1]
                    }
                }

                const cate = {
                    type_id,
                    type_name,
                    vod_list: []
                }
                const $items = select($module, ".//div[contains(@class, 'module-lines-list')]/div[contains(@class, 'module-items')]/div[contains(@class, 'module-item')]")
                $items.forEach($item => {
                    const vod_pic = select($item, ".//div[contains(@class, 'module-item-pic')]/img/@data-src")[0]?.value?.trim();
         
                    const vod_name =  select($item, ".//div[contains(@class, 'module-item-pic')]/a/@title")[0]?.value?.trim();
                    const vod_id =  select($item, ".//div[contains(@class, 'module-item-pic')]/a/@href")[0]?.value?.trim();
                    const vod_remarks =  select($item, "./div[contains(@class, 'module-item-text')]/text()")?.toString()?.trim();
                    cate.vod_list.push({
                        vod_id,
                        vod_pic,
                        vod_name,
                        vod_remarks,
                        direction: direction.vertical
                    })
                })

                result.push(cate)
            })
        }
        writeFileSync('home.json', result)
        return success(result)
    } catch (e) {
        console.error(e)
        return error(e.message)
    }
}

async function detail({ vod_id }) {
    try {
        const url = vod_id.startsWith('http') ? vod_id : `${host}${vod_id}`
        const resposne = await request(url)
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();
        writeFileSync('detail.html', notStandardHtml)

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');
        const $content = select(document, "//main[contains(@id, 'main')]/div[contains(@class, 'content')]")[0]
        if(!$content) throw new Error('解析资源失败 content not Found')

        //
        const $heading = select($content, "./div[contains(@class, 'view-heading')]")[0]
        const $info = select($heading, ".//div[contains(@class, 'video-info')]")[0]
        if(!$info) throw new Error('解析资源失败 info not Found')
    
        let vod_actor = ''
        let vod_area = ''
        let vod_class = ''
        let vod_lang = ''
        let vod_time = ''
        let vod_year = ''
        let vod_remarks = ''

        let vod_name = "";
        let vod_pic = "";
        let vod_content = "";

        const vod_sources = []

        const actor_label = "主演："
        const area_label = "地区："
        const class_label = "分类："
        const time_label = "更新："
        const year_label = "上映："
        const remarks_label = "备注："

        vod_name = (select($info, ".//h1[contains(@class, 'page-title')]/text()") || "").toString().trim();
        vod_pic = select($heading, ".//div[contains(@class, 'video-cover')]//img/@data-src")[0]?.value;

        const $rows = select($info, "./div[contains(@class, 'video-info-main')]/div[contains(@class, 'video-info-items')]")
        if ($rows.length) {
            $rows.forEach((node, i) => {
                const text = select(node, "./span[contains(@class, 'video-info-itemtitle')]/text()")?.toString()?.trim();
                if (text.startsWith(actor_label)) {
                    const actors = [];
                    const $links = select(node, './div[contains(@class,"video-info-actor")]/a')
                    $links.forEach((link, i) => {
                        const actor = select(link, ".//text()")?.toString()?.trim();
                        actor && actors.push(actor)
                    })

                    vod_actor = actors.join(',')
                } else if (text.startsWith(year_label)) {
                    const value = select(node, "./div[contains(@class, 'video-info-item')]/text()")?.toString()?.trim();
                    vod_year = value
                } else if (text.startsWith(remarks_label)) {
                    const value = select(node, "./div[contains(@class, 'video-info-item')]/text()")?.toString()?.trim();
                    vod_remarks = value
                }
            })
        }

        
        const $urls = select($content, ".//div[contains(@class, 'module-player-list')]/div[contains(@class, 'module-blocklist')]/div[contains(@class, 'scroll-content')]/a")

        if($urls.length) {

            const source = {
                source_name: '官网',
                vod_play_list: {
                    url_count: $urls.length,
                    urls: []
                }
            }
            $urls.forEach(($link, i) => {
                const url = {
                    name: '',
                    url: ''
                }
                url.name = select($link, "./@title")[0]?.value?.trim();
                url.url = select($link, ".//@href")[0]?.value?.trim();
                source.vod_play_list.urls.push(url);
            
            })
            vod_sources.push(source)

        }

        const result = {
            vod_actor,
            vod_area,
            vod_class,
            vod_content,
            vod_id,
            vod_lang,
            vod_name,
            vod_pic,
            vod_time,
            vod_year,
            vod_remarks,
            vod_sources,
            similar: similar($content)
        }
        writeFileSync('detail.json', result)

        return success(result)
    } catch (e) {
        console.error(e)
        return error(e.message);
    }
}

function similar($content) {
    try {
        const $module = select($content, "./div[contains(@class, 'module')]")[1]
        if(!$module) throw new Error('解析失败')
    
        const $list = select($module, ".//div[contains(@class, 'module-lines-list')]/div[contains(@class, 'module-items')]/div[contains(@class, 'module-item')]")
        const list = []
        if ($list.length) {
            $list.forEach((node) => {
                const vod_pic = select(node, ".//div[contains(@class, 'module-item-pic')]/img/@data-src")[0]?.value?.trim();
         
                const vod_name =  select(node, ".//div[contains(@class, 'module-item-pic')]/a/@title")[0]?.value?.trim();
                const vod_id =  select(node, ".//div[contains(@class, 'module-item-pic')]/a/@href")[0]?.value?.trim();
                const vod_remarks =  select(node, "./div[contains(@class, 'module-item-text')]/text()")?.toString()?.trim();
                list.push({
                    vod_id,
                    vod_pic,
                    vod_name,
                    vod_remarks,
                    direction: direction.vertical
                })
            })
        }
        return list
    } catch (e) {
        console.error(e)
        return []
    }

}
async function play({url}) {
    try {
        const fetchUrl = url.startsWith('http') ? url : `${host}${url}`
        const resposne = await request(fetchUrl)
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();
        writeFileSync('play.html', notStandardHtml)

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');
        const playUrl = parsePlayUrl(document)
        return success(playUrl)
    } catch(e) {
        return error(e.message)
    }
}

async function list(type_id, page) {
    try {
        const response = await request(`${host}/vodtype/${type_id}-${page}.html`)
        const notStandardHtml = await response.text()
        writeFileSync('list.html', notStandardHtml)
        // const notStandardHtml = readFileSync('home.html')
         // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
         const doc5 = parse5.parseFragment(notStandardHtml);
         const html = parse5.serialize(doc5);
 
         const document = new dom().parseFromString(html, "text/html");

         let $main =  select(
            document,
            "//main[contains(@id, 'main')]/div[contains(@class, 'content')]")[0]
            
        if(!$main) throw new Error('解析出错 main nout found')
        const list = [];
        let pages = 1;

        const $list =  select($main, "./div[contains(@class, 'module')]/div[contains(@class, 'module-list')]/div[contains(@class, 'module-items')]/div[contains(@class, 'module-item')]")
        if($list.length) {
            $list.forEach($item => {
                const vod_pic = select($item, ".//div[contains(@class, 'module-item-pic')]/img/@data-src")[0]?.value?.trim();
         
                const vod_name =  select($item, ".//div[contains(@class, 'module-item-pic')]/a/@title")[0]?.value?.trim();
                const vod_id =  select($item, ".//div[contains(@class, 'module-item-pic')]/a/@href")[0]?.value?.trim();
                const vod_remarks =  select($item, "./div[contains(@class, 'module-item-text')]/text()")?.toString()?.trim();
                list.push({
                    vod_id,
                    vod_pic,
                    vod_name,
                    vod_remarks,
                    direction: direction.vertical
                })
            })
        }

        const $pages =  select($main, ".//div[contains(@id, 'page')]")[0];
        if($pages) {
            const lastHref = select($pages, "./a[contains(@class, 'page-next') and last()]/@href")[0]?.value
            if (lastHref) {
                const matchVal = lastHref.match(/(\d+)\.html$/);
                if (matchVal) {
                    pages = Number(matchVal[1])
                }
            }
        }
   
    
        const result = {
            page,
            pages,
            list
        }
        writeFileSync('list.json', result)
        return success(result)
    } catch (e) {
        console.error(e)
        return error(e.message)
    }
}

async function search(keyword, page) {
    try {
        const response = await request(`${host}/vodsearch/${keyword}----------${page}---.html`)
        const notStandardHtml = await response.text()
        writeFileSync('search.html', notStandardHtml)
        // const notStandardHtml = readFileSync('home.html')
         // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
         const doc5 = parse5.parseFragment(notStandardHtml);
         const html = parse5.serialize(doc5);
         const document = new dom().parseFromString(html, "text/html");

         let $main =  select(
            document,
            "//main[contains(@id, 'main')]/div[contains(@class, 'content')]")[0]
            
        if(!$main) throw new Error('解析出错 main nout found')
        const list = [];
        let pages = 1;

        const $list =  select($main, "./div[contains(@class, 'module')]/div[contains(@class, 'module-list')]/div[contains(@class, 'module-items')]/div[contains(@class, 'module-search-item')]")
        if($list.length) {
            $list.forEach($item => {
                const vod_pic = select($item, ".//div[contains(@class, 'module-item-pic')]/img/@data-src")[0]?.value?.trim();
         
                const vod_name =  select($item, ".//div[contains(@class, 'video-info')]/h3/a/@title")[0]?.value?.trim();
                const vod_id =  select($item, ".//div[contains(@class, 'video-info')]/h3/a/@href")[0]?.value?.trim();
                const vod_remarks =  select($item, ".//a[contains(@class, 'video-serial')]/text()")?.toString()?.trim();
                list.push({
                    vod_id,
                    vod_pic,
                    vod_name,
                    vod_remarks,
                    direction: direction.vertical
                })
            })
        }

        const $pages =  select($main, ".//div[contains(@id, 'page')]")[0];
        if($pages) {
            const lastHref = select($pages, "./a[contains(@class, 'page-next') and last()]/@href")[0]?.value
            if (lastHref) {
                const matchVal = lastHref.match(/(\d+)(---)?\.html$/);
                if (matchVal) {
                    pages = Number(matchVal[1])
                }
            }
        }
   
    
        const result = {
            page,
            pages,
            list
        }
        writeFileSync('search.json', result)
        return success(result)
    } catch (e) {
        console.error(e)
        return error(e.message)
    }
}

function parsePlayUrl(document) {
    let vod_play_url = ""
    const $script = select(document, ["//main[contains(@id, 'main')]//div[contains(@class, 'player-box-main')]//div[contains(@class, 'player-wrapper')]/script"])[0]
    if ($script) {
        const content = select($script, ".//text()")?.toString()?.trim();
        if (content.indexOf('var player_aaaa=') !== -1) {
            const json = JSON.parse(content.substring(content.indexOf("{")));
            if (json && json.url) {
                vod_play_url = json.url
            }
        }
    }
    return vod_play_url;
}

module.exports.home = home
module.exports.detail = detail
module.exports.play = play
module.exports.list = list
module.exports.search = search
