const { success, error } = require('./lib/response');
const { request, getHeader, kDefaultReferer, kDefaultUserAgent, cookie } = require('./lib/request.js')
const { getWbiSign, getBuvid } = require('./lib/sign.js')
const { writeFileSync } = require('./lib/debug.js')

const direction = {
    horizontal: "horizontal",
    vertical: "vertical",
};
  

const userId = 0;

/**
 * 通过home接口请求的分类数据，以type_id为key
 */
const HomeCateMap = {}

/**
 * 获取首页分类
 * @returns 
 */
async function home() {
    try {
        const response = await request(`https://api.live.bilibili.com/room/v1/Area/getList?${new URLSearchParams({
            "need_entrance": 1,
            "parent_id": 0,
        }).toString()}`, {
            headers: getHeader()
        })
        const json = await response.json();
        writeFileSync('home.json', json)
        if (json.code !== 0 || !Array.isArray(json?.data)) {
            throw new Error('获取接口出错')
        }

        // const categories = []
        json.data.forEach(item => {
            HomeCateMap[item.id] = item
            // categories.push({
            //     type_id: item.id,
            //     type_name: item.name,
            //     vod_list: [],
            //     type_type: 'other'
            // })
        })

        const categories = [
            {
                type_id: 3, type_name: "手游", vod_list: [], type_type: 'other',
            },
            {
                type_id: 2, type_name: "网游", vod_list: [], type_type: 'other',
            },
            {
                type_id: 6, type_name: "单机", vod_list: [], type_type: 'other',
            },
            {
                type_id: 1, type_name: "娱乐", vod_list: [], type_type: 'other',
            }
        ]
        return success(categories)
    } catch (e) {
        return error(e.message)
    }
}

/**
 * 根据type_id 返回类标数据
 * @param {*} type_id 
 * @returns 
 */
async function cate(type_id) {
    try {
        const cate = HomeCateMap[type_id]
        if(!cate) {
            throw new Error(`分类不存在: ${type_id}`)
        }

        return success(cate.list.map(item => (
           {
            type_id: `${item.parent_id}-${item.id}`,
            type_name: item.name,
            vod_list: [],
           }
        )))
       
    } catch (e) {
        return error(e.message)
    }
}

/**
 * 分类列表
 * @param {*} type_id 
 * @param {*} page 
 * @returns 
 */
async function list(type_id, page = 1) {
    try {
        const [parend_id, id] = type_id.split('-')
        const params = new URLSearchParams({
            "platform": "web",
            "parent_area_id":parend_id,
            "area_id": id,
            "sort_type": "",
            "page": page
          });
        const response = await request(
            `https://api.live.bilibili.com/xlive/web-interface/v1/second/getList?${params.toString()}`,
            {
                headers: getHeader()
            }    
        );
        const json = await response.json();
        writeFileSync('list.json', json)
        if (json.code !== 0 || !json.data) {
            throw new Error('获取接口出错')
        }

        const rs = json.data;
        const items = []
        const list = rs.list ?? [];

        list.forEach(item => {
            items.push({
                vod_id: item.roomid,
                roomId: item.roomid,
                vod_name: item.title,
                vod_pic: item.rs16,
                vod_actor: item.uname,
                vod_avatar: `${item.cover}@400w.jpg`,
                vod_blurb: item.verify.desc,
                online: Number(item.online) ?? 0,
                direction: direction.horizontal
            })
        })
        const hasMore = rs.has_more == 1
        return success({
            // 接口没有分页参数，只能伪造一个还有更多的pages
            pages: hasMore ? page + 1 : page,
            page,
            list: items
        });

    } catch (e) {
        return error(e.message)
    }
}

/**
 * 搜索
 * @param {*} keyword 
 * @param {*} page 
 * @param {*} pagesize 
 * @returns 
 */
async function search(keyword, page = 1, pagesize = 20) {
    try {
        const params = new URLSearchParams({
            "order": "",
            "keyword": keyword,
            "category_id": "",
            "__refresh__": "",
            "_extra": "",
            "highlight": 0,
            "single_column": 0,
            "page": page
        })
        const response = await request(`https://api.bilibili.com/x/web-interface/search/type?context=&search_type=live&cover_type=user_cover&${params.toString()}`, {
            headers: {
                "cookie": cookie ? 'buvid3=infoc;' : cookie,
                "user-agent": kDefaultUserAgent,
                "referer": kDefaultReferer,
              },
        })
        const result = await response.json();

        writeFileSync('search.json', result);

        const items = [];

        for (const item of result?.data?.result?.live_room ?? []) {
            //移除title中的<em></em>标签
            const title = item.title.replace(/<.*?em.*?>/g, "");
            const roomItem = {
                vod_id: item.roomid,
                roomId: item.roomid,
                vod_name: title,
                vod_pic: `https:${item.cover}@400w.jpg`,
                vod_avatar: `https:${item.user_cover}`,
                vod_actor: item.uname,
                // vod_blurb: item.game_introduction,
                online: parseInt(item.online) || 0,
                direction: direction.horizontal
            };
            items.push(roomItem);
        }
        const hasMore = items.length >= 40 // rs.has_more == 1
        return success({
            // 接口没有分页参数，只能伪造一个还有更多的pages
            pages: hasMore ? page + 1 : page,
            page,
            list: items
        });
    } catch (e) {
        return error(e.message)
    }

}

/**
 * 获取播放详情
 * @param {*} param0 
 * @returns 
 */
async function detail({ vod_id,roomId }) {
    try {
        const id = vod_id || roomId;
        const roomInfo = await getRoomInfo(id);
        const realRoomId = roomInfo["room_info"]["room_id"].toString();
        const response = await request(
            `https://api.live.bilibili.com/xlive/web-room/v1/index/getDanmuInfo?id=${realRoomId}`,
            {
                headers: getHeader()
            }
        );

        const json = await response.json();
        writeFileSync(`detail_${id}.json`, json)

        // const serverHosts = json.data.host_list.map((e) => e.host.toString());
        
        // const buvid = await getBuvid();

        const detail = {
            vod_id: realRoomId,
            roomId: realRoomId,
            vod_name: roomInfo.room_info.title,
            vod_pic:roomInfo.room_info.cover,
            vod_actor: roomInfo.anchor_info.base_info.uname,
            vod_avatar: `${roomInfo["anchor_info"]["base_info"]["face"]}@100w.jpg`,
            vod_blurb: roomInfo["room_info"]["description"],
            online: Number(roomInfo.room_info.online),
            notice: "",
            status: (Number(roomInfo.room_info.live_status == 1) ?? 0 ) === 1,
            vod_sources: []
        }

        const qualities = await getPlayQualites(detail.vod_id);

        for (let i = 0, len = qualities.length; i < len; i++) {
            const quality = qualities[i];
            const urls = await getPlayUrls(detail.vod_id, quality);

            if (urls.length) {
              detail.vod_sources.push({
                source_name: quality.quality,
                vod_play_list: {
                  // 兼容虎牙结构
                  urls: [{
                    name: quality.quality,
                    urls
                  }],
                  url_count: urls.length,
                },
              });
            }
          }

        return success(detail)

    } catch (e) {
        console.log(e.stack)
        return error('detail => ' +e.message)
    }

}

async function play(url) {
    return Promise.resolve(success(url))
}

/**
 * 获取房间信息
 * @param {*} id 
 * @returns 
 */
async function getRoomInfo(id) {
    const url = `https://api.live.bilibili.com/xlive/web-room/v1/index/getInfoByRoom?room_id=${id}`
    const queryParams = await getWbiSign(url);
    const response = await request(`https://api.live.bilibili.com/xlive/web-room/v1/index/getInfoByRoom?${queryParams}`, {
        headers: getHeader()
    })

    const json = await response.json();
    writeFileSync(`room_${id}.json`, json)
    return json?.data
}

/**
 * 获取播放线路
 * @param {*} detail 
 * @returns 
 */
async function getPlayQualites(id) {
    const url = `https://api.live.bilibili.com/xlive/web-room/v2/index/getRoomPlayInfo`

    const params = new URLSearchParams({
        "room_id": id,
        "protocol": "0,1",
        "format": "0,1,2",
        "codec": "0,1",
        "platform": "web",
      });

    const response = await request(`${url}?${params.toString()}`, {
        headers: getHeader()
    })

    const json = await response.json();
    writeFileSync(`qualites_${id}.json`, json)
    const qualitiesMap = {}


    json.data.playurl_info.playurl.g_qn_desc.forEach(item => {
        qualitiesMap[item.qn ?? 0] = item.desc
    })

    const qualities = []

    json["data"]["playurl_info"]["playurl"]["stream"][0]
        ["format"][0]["codec"][0]["accept_qn"].forEach(item => {
      const qualityItem = {
        quality: qualitiesMap[item] ?? "未知清晰度",
        data: item,
      };
      qualities.push(qualityItem);
    })

    return qualities
}

/**
 * 获取指定线路的播放链接
 * @param {*} detail 
 * @param {*} qulity 
 * @returns 
 */
async function getPlayUrls(id, quality) {
    const url = `https://api.live.bilibili.com/xlive/web-room/v2/index/getRoomPlayInfo`

    const params = new URLSearchParams({
        "room_id": id,
        "protocol": "0,1",
        "format": "0,2",
        "codec": "0",
        "platform": "web",
        "qn": quality.data,
      });

    const response = await request(`${url}?${params.toString()}`, {
        headers: getHeader()
    })

    const json = await response.json();
    writeFileSync(`urls_${id}.json`, json)

    const urls = []

    const streamList = json["data"]["playurl_info"]["playurl"]["stream"];
    streamList.forEach(streamItem => {
        const formatList = streamItem["format"];
        formatList.forEach(formatItem => {
            const codecList = formatItem["codec"];
            codecList.forEach(codecItem => {
                const urlList = codecItem["url_info"];
                const baseUrl = codecItem["base_url"].toString();
                urlList.forEach(urlItem => {
                    urls.push(
                      `${urlItem["host"]}${baseUrl}${urlItem["extra"]}`
                    );
                })
            })
        })

    })

    // 对链接进行排序，包含mcdn的在后
    urls.sort((a, b) =>{
    if (a.includes("mcdn")) {
        return 1;
    } else {
        return -1;
    }
    });

    return urls;
}

module.exports.home = home
module.exports.cate = cate
module.exports.list = list
module.exports.search = search
module.exports.detail = detail
module.exports.play = play
module.exports.room = getRoomInfo