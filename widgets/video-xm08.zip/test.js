const widget = require("./widget.js");

(async () => {
    const [, , method, param] = process.argv;

    if (!method) {
        console.error("请提供要执行的方法名称");
        process.exit(1);
    }

    // # 首页接口数据测试
    if (method === "home") {
        const home = await widget.home();
        console.log(home);

        // 测试缓存
        // const data = await widget.list(6, 1);
        // console.log(data);
    }

    // # type_id 列表测试
    if (method === "list") {
        const data = await widget[method](param, 1);
        console.log(data);
    }

    // 测试分类列表
    if (method === "getTypeList") {
        const data = await widget[method]({
            type_id: param,
            page: 1
        });
        console.log(data);
    }

    // # 详情页接口数据测试
    if (method === "detail") {
        const detail = await widget.detail({
            vod_id: param
        });
        console.log(detail);
    }

    // # 搜索关键字测试
    if (method === "search") {
        const search = await widget.search(param, 1);
        console.log(search);
    }

    // # 关键词相似影片测试
    if (method === "similar") {
        const similar = await widget.similar({
            vod_id: param
        });
        console.log(similar);
    }
})();
