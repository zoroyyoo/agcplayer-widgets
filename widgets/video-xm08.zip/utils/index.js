/**
 * 根据网址获取对应ID： /type/1.html => 1
 */
function getTypeIdByUrl(url) {
    // 需要处理错误，获取不到的返回-1
    try {
        return Number(url.match(/\/type\/(\d+)\.html/)[1]);
    } catch (e) {
        return -1;
    }
}

function getPageNumber(str) {
    const regex = /\/type\/2-(\d+)\.html/;
    const match = str.match(regex);

    if (match && match[1]) {
        return parseInt(match[1], 10);
    } else {
        return 1;
    }
}

function getVodIdNumber(str) {
    const regex = /\/detail\/(\d+)\.html/;
    const match = str.match(regex);

    if (match && match[1]) {
        return parseInt(match[1], 10);
    } else {
        return -1;
    }
}

function extractUrlFromHTML(htmlString) {
    try {
        const regex =
            /video\s*:\s*{\s*url\s*:\s*"(.*?)",\s*type\s*:\s*'customHls'/;
        const match = htmlString.match(regex);

        if (match) {
            return match[1];
        } else {
            return "";
        }
    } catch (e) {
        return "";
    }
}

function extractUrlFromButton(htmlString) {
    try {
        // 这个正则表达式匹配常见的媒体URL格式
        // 匹配http/https开头，包含各种媒体文件扩展名(.m3u8, .mp4, .mp3等)的URL
        const regex =
            /(https?:\/\/[^\s'"]+\.(m3u8|mp4|mp3|avi|mkv|flv|mov|wmv|ts|m4v|webm))/i;

        // 也可以使用更通用的URL匹配正则，但可能会捕获非媒体URL
        const genericUrlRegex = /(https?:\/\/[^\s'"]+)/i;

        // 首先尝试匹配媒体特定URL
        const mediaMatch = htmlString.match(regex);
        if (mediaMatch && mediaMatch[1]) {
            return mediaMatch[1];
        }

        // 如果没有匹配到媒体特定URL，尝试匹配通用URL
        const genericMatch = htmlString.match(genericUrlRegex);
        if (genericMatch && genericMatch[1]) {
            return genericMatch[1];
        }

        // 如果都没有匹配到，返回null
        return null;
    } catch (e) {
        return "";
    }
}

module.exports = {
    getTypeIdByUrl,
    getPageNumber,
    getVodIdNumber,
    extractUrlFromHTML,
    extractUrlFromButton
};
