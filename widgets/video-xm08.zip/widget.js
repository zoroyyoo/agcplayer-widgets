const { request, unescapeEntity, success, error } = require("./core");
const Cheerio = require("./core/cheerio");
const Cache = require("./core/cache");
const { extractUrlFromButton } = require("./utils");

const cheerio = new Cheerio();
const cache = new Cache();

const headers = {
    accept: "*/*",
    "accept-language":
        "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7,de;q=0.6,zh-TW;q=0.5",
    "cache-control": "no-cache",
    dnt: "1",
    pragma: "no-cache",
    priority: "u=1, i",
    referer: "https://youku.xm08.cn/",
    "sec-ch-ua":
        '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"macOS"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "user-agent":
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "x-requested-with": "XMLHttpRequest"
};

const appConfig = {
    version: 1,
    title: "xm08",
    site: "https://youku.xm08.cn",
    typeUrl: (type_id, page) =>
        `${appConfig.site}/api.php?action=load_more&type=${type_id}&page=${page}`,
    playUrl: vod_id => `${appConfig.site}/movie_detail.php?vod_id=${vod_id}`,
    direction: "vertical",
    // https://youku.xm08.cn/api.php?action=get_types 所有分类写死一次配置
    typeMap: [
        { type_id: 6, type_name: "动作片" },
        { type_id: 7, type_name: "喜剧片" },
        { type_id: 8, type_name: "爱情片" },
        { type_id: 9, type_name: "科幻片" },
        { type_id: 10, type_name: "恐怖片" },
        { type_id: 11, type_name: "剧情片" },
        { type_id: 12, type_name: "战争片" },
        { type_id: 13, type_name: "国产剧" },
        { type_id: 14, type_name: "香港剧" },
        { type_id: 15, type_name: "韩国剧" },
        { type_id: 16, type_name: "欧美剧" },
        { type_id: 20, type_name: "记录片" },
        // { type_id: 21, type_name: "台湾剧" },
        // { type_id: 22, type_name: "日本剧" },
        // { type_id: 24, type_name: "泰国剧" },
        // { type_id: 25, type_name: "大陆综艺" },
        // { type_id: 26, type_name: "港台综艺" },
        // { type_id: 27, type_name: "日韩综艺" },
        // { type_id: 28, type_name: "欧美综艺" },
        { type_id: 29, type_name: "国产动漫" },
        { type_id: 30, type_name: "日韩动漫" },
        { type_id: 32, type_name: "港台动漫" },
        { type_id: 33, type_name: "海外动漫" },
        // { type_id: 35, type_name: "电影解说" },
        // { type_id: 37, type_name: "足球" },
        // { type_id: 38, type_name: "篮球" },
        // { type_id: 39, type_name: "网球" },
        // { type_id: 40, type_name: "斯诺克" },
        // { type_id: 46, type_name: "短剧" }
    ]
};

/**
 * 获取分类列表
 */
async function getTypeList({ type_id, page = 1, size = 20 }) {
    if (cache.get(`type:${type_id}:page:${page}`)) {
        return cache.get(`type:${type_id}:page:${page}`);
    }

    const restype = await request(appConfig.typeUrl(type_id, page), {
        headers
    });
    const resdata = await restype.json();

    const list = resdata.map(item => {
        return {
            vod_id: item.vod_id,
            vod_name: item.vod_name,
            vod_pic: item.vod_pic,
            vod_remarks: item.vod_remarks,
            vod_actor: item.vod_actor,
            vod_area: item.vod_area,
            vod_year: item.vod_year,
            vod_blurb: unescapeEntity(item.vod_blurb),
            vod_lang: item.vod_lang,
            vod_duration: Number(item.vod_duration),
            vod_direction: appConfig.direction,
        };
    });

    const total = resdata.length * 100;
    const pages = Math.ceil(total / size);

    return {
        page,
        total,
        pages,
        list
    };
}

async function home() {
    let categories = [];
    const { typeMap } = appConfig;

    const results = await Promise.allSettled(
        typeMap.map(async item => {
            return getTypeList({
                type_id: item.type_id
            });
        })
    );

    results.forEach(async (item, index) => {
        if (item.status === "fulfilled") {
            if (item.value) {
                categories.push({
                    type_id: typeMap[index]["type_id"],
                    type_type: "other",
                    type_name: typeMap[index]["type_name"],
                    vod_list: item.value.list
                });

                cache.set(
                    `type:${typeMap[index]["type_id"]}:page:1`,
                    item.value
                );
            }
        }
    });

    return success(categories);
}

async function list(type_id, page = 1) {
    const data = await getTypeList({
        type_id,
        page
    });

    return success(data);
}

async function detail({ vod_id, type_id }) {
    if (cache.get(`detail:${vod_id}`)) {
        return success(cache.get(`detail:${vod_id}`));
    }

    try {
        const response = await request(appConfig.playUrl(vod_id), {
            headers
        });
        const html = await response.text();

        const $ = cheerio.load(html);

        const vod_name = unescapeEntity($(".movie-details .card-title").text());
        const vod_pic = $(".poster-container .img-fluid").attr("src");
        const vod_blurb = unescapeEntity($(".movie-description > p").text());
        const vod_actor = $(".movie-info .movie-info-item")
            .eq(0)
            .find("p")
            .text();
        const vod_remarks = $(".poster-container .remarks-badge").text();
        const vod_year = "";
        const vod_link = [];
        const similar = cache.get(`type:${type_id}:page:1`) || [];

        $(".play-buttons .play-button").each((_, item) => {
            const name = $(item).text();
            const url = extractUrlFromButton($(item).attr("onclick"));
            vod_link.push({
                name,
                url
            });
        });

        const vod_info = {
            vod_blurb,
            vod_id,
            vod_name,
            vod_remarks,
            vod_pic,
            vod_year,
            vod_actor,
            vod_time: "",
            vod_lang: "cn",
            vod_area: "",
            vod_class: "",
            vod_remarks: "",
            similar,
            vod_sources: [
                {
                    source_name: "选集列表",
                    vod_play_list: {
                        url_count: vod_link.length,
                        urls: vod_link
                    }
                }
            ]
        };

        cache.set("detail:" + vod_id, vod_info);

        return success(vod_info);
    } catch (e) {
        return error(e.message);
    }
}

async function search(keyword, page = 1) {
    if (cache.get(`search:${keyword}`)) {
        return success(cache.get(`search:${keyword}`));
    }

    try {
        const params = new URLSearchParams();
        params.append("search_query", keyword);

        const response = await request(`${appConfig.site}/search.php`, {
            method: "POST",
            body: params.toString(),
            headers: {
                accept: "*/*",
                "accept-language":
                    "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7,de;q=0.6,zh-TW;q=0.5",
                "cache-control": "no-cache",
                "content-type":
                    "application/x-www-form-urlencoded; charset=UTF-8",
                dnt: "1",
                origin: "https://youku.xm08.cn",
                pragma: "no-cache",
                priority: "u=1, i",
                referer: "https://youku.xm08.cn/",
                "sec-ch-ua":
                    '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"macOS"',
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin",
                "user-agent":
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
                "x-requested-with": "XMLHttpRequest"
            }
        });

        const resdata = await response.json();

        const list = resdata.movies.map(item => {
            return {
                ...item,
                vod_direction: appConfig.direction
            };
        });

        const total = list.length;
        const pages = page;
        const result = {
            total,
            page,
            pages,
            list
        };

        cache.set(`search:${keyword}`, result);
        return success(result);
    } catch (e) {
        console.log(e.message);
        return error(e.message);
    }
}

async function play({ url }) {
    try {
        return success(url);
    } catch (e) {
        console.error(e);
        return error(e.message);
    }
}

async function similar({ vod_id, type_id }) {
    return success(cache.get(`type:${type_id}:page:1`) || []);
}

module.exports.home = home;
module.exports.list = list;
module.exports.search = search;
module.exports.detail = detail;
module.exports.similar = similar;
module.exports.play = play;
module.exports.getTypeList = getTypeList;
