module.exports.apis = {
    cate: (type_id) => `https://api.olelive.com/v1/pub/index/vod/data/${type_id}`,
    list: (type_id, page) => `https://api.olelive.com/v1/pub/vod/list/true/3/0/0/${type_id}/0/0/update/${page}/48`,
    search: (keyword, page) => `https://api.olelive.com/v1/pub/index/search/${keyword}/vod/0/${page}/12`,
    detail: (vod_id) => `https://api.olelive.com/v1/pub/vod/detail/${vod_id}/true`,
    similar: (typeId1, typeId) => `https://api.olelive.com/v1/pub/vod/random/${typeId1}/${typeId}/8`
}