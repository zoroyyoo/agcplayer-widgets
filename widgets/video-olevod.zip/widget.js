const { request } = require('./lib/request.js')
const { success, error } = require('./lib/response.js')
const { formatDate, unescapeEntity, sleep } = require('./lib/index.js')
const { apis } = require('./config.js')
const { writeFileSync } = require('./lib/debug.js')

const TypeMap = {
    '12': '电视直播',
    '14': '短剧',
    '1': '电影',
    '2': '连续剧',
    '3': '综艺',
    '4': '动漫'
}

module.exports.home = async function home() {
    try {
        const categories = []
        const results = await Promise.allSettled([
            // 电影
            getCate(1),
            // 连续剧
            getCate(2),
            // 综艺
            getCate(3),
            // 动漫
            getCate(4),
            // 短剧
            getCate(14),
        ])
        results.forEach(async (item, i) => {
            if (item.status === 'fulfilled') {
                if (item.value) {
                    categories.push(item.value)
                }
            }
        })
        writeFileSync('home.json', categories)
        return success(categories)
    } catch (e) {
        console.log(`home error: ${e.stack}`)
        return error(e.message)
    }
}

module.exports.list = async function list(type_id, page = 1) {
    try {
        const response = await request(apis.list(type_id, page))
        const json = await response.json();
        if (!json || json.code !== 0) throw new Error(`获取list接口出错 code: ${json?.code}`)
        const list = json.data.list ?? [];
        const pages = json.data.pageSize || 1;
        const result = {
            page,
            pages,
            list: list.map(item => ({
                vod_id: item.id,
                vod_pic: item.pic?.startsWith('http') ? item.pic : `https://www.olevod.com/${item.pic}`,
                vod_name: item.name,
                vod_remarks: `${item.vip ? 'VIP - ' : ''}${item.remarks}`,
                vod_actor: item.actor?.replace(/(\s)?\/(\s)?/g, ','),
                vod_blurb: unescapeEntity(item.blurb ?? ''),
                direction: 'vertical'
            }))
        }

        writeFileSync('list.json', result)

        return success(result)
    } catch (e) {
        console.log(`list error: ${e.stack}`)
        return error(e.message)
    }
}

module.exports.search = async function search(keyword, page = 1) {
    try {
        const response = await request(apis.search(keyword, page))
        const json = await response.json();
        if (!json || json.code !== 0) throw new Error(`获取search接口出错 code: ${json?.code}`)
        const data = (json.data.data ?? []).find(item => item.type === 'vod');

        const pages = data?.pageSize || 1;
        const list = data?.list || [];

        const result = {
            page,
            pages,
            list: list.map(item => ({
                vod_id: item.id,
                vod_pic: item.pic?.startsWith('http') ? item.pic : `https://www.olevod.com/${item.pic}`,
                vod_name: item.name,
                vod_remarks: `${item.vip ? 'VIP - ' : ''}${item.remarks}`,
                vod_actor: item.actor?.replace(/(\s)?\/(\s)?/g, ','),
                vod_blurb: unescapeEntity(item.blurb ?? ''),
                direction: 'vertical'
            }))
        }
        writeFileSync('search.json', result)

        return success(result)
    } catch (e) {
        console.log(`search error: ${e.stack}`)
        return error(e.message)
    }
}

module.exports.detail = async function detail({vod_id}) {
    try {
        const response = await request(apis.detail(vod_id))
        const json = await response.json();
        if (!json || json.code !== 0) throw new Error(`获取详情接口出错 code: ${json?.code}`)
        const data = json.data;
        console.log(data)
        const similar = await getSimilar(data.typeId1, data.typeId)
        const result = {
            vod_id,
            vod_name: data.name,
            vod_pic: data.pic?.startsWith('http') ? data.pic : `https://www.olevod.com/${data.pic}`,
            vod_actor: data.actor?.replace(/(\s)?\/(\s)?/g, ','),
            vod_content: unescapeEntity(data.content ?? ''),
            vod_class: data.typeIdName,
            vod_area: data.area,
            vod_lang: data.lang,
            vod_year: data.year,
            vod_remarks: `${data.vip ? 'VIP - ' : ''}${data.remarks}`,
            vod_time: formatDate(data.vodTime * 1000),
            vod_sources: [{
                source_name: "官方",
                vod_play_list: {
                    url_count: data.urls?.length || 0,
                    urls: (data.urls ?? []).map(item => ({
                        name: item.title,
                        url: item.url
                    }))
                }
            }],
            similar
        }
        writeFileSync('detail.json', result)

        return success(result)
    } catch (e) {
        console.log(`list error: ${e.stack}`)
        return error(e.message)
    }
}

module.exports.play = function ({url}) {
    return Promise.resolve(success(url));
}

async function getSimilar(typeId1, typeId) {
    try {
        const response = await request(apis.similar(typeId1, typeId))
        const json = await response.json();
        if (!json || json.code !== 0) throw new Error(`获取similar接口出错 code: ${json?.code}`)
        const data = json.data ?? [];
        const result = data.map(item => ({
            vod_id: item.id,
            vod_pic: item.pic?.startsWith('http') ? item.pic : `https://www.olevod.com/${item.pic}`,
            vod_name: item.name,
            vod_remarks: `${item.vip ? 'VIP - ' : ''}${item.remarks}`,
            vod_actor: item.actor?.replace(/(\s)?\/(\s)?/g, ',') ?? '',
            vod_blurb: unescapeEntity(item.blurb ?? ''),
            direction: 'vertical'
        }))
        writeFileSync('similar.json', result)

        return result
    } catch (e) {
        console.log(`similar接口异常, ${e.stack}`)
        return []
    }
}

async function getCate(type_id) {
    try {
        const response = await request(apis.cate(type_id))
        const json = await response.json();
        if (!json || json.code !== 0) throw new Error(`获取getCate接口出错 code: ${json?.code}`)
        const data = json.data;
        return {
            type_id: String(type_id),
            type_name: TypeMap[type_id] ?? `分类_${type_id}`,
            vod_list: (data?.list ?? []).map(item => ({
                vod_id: item.id,
                vod_pic: item.pic?.startsWith('http') ? item.pic : `https://www.olevod.com/${item.pic}`,
                vod_name: item.name,
                vod_remarks: `${item.vip ? 'VIP - ' : ''}${item.remarks}`,
                vod_actor: item.actor?.replace(/(\s)?\/(\s)?/g, ',') ?? '',
                vod_blurb: unescapeEntity(item.blurb ?? ''),
                direction: 'vertical'
            }))
        }
    } catch (e) {
        console.log(`getCate Error, type_id: ${type_id}, error: ${e.stack}`)
    }
}