const { MD5, Base64, Utf8 } = require('./polyfill/index.js')
const pLimit = require('./polyfill/p-limt.js')
const { success, error } = require('./Library/response');

// const fs = require('fs');

const ua = "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36 Edg/117.0.0.0";
const id = "huya"
const name = "虎牙直播"

const direction = {
    horizontal: 'horizontal',
    vertical: 'vertical'
}

function http(url, options = {}) {
    const defaultOptions = {
        headers: {
            "user-agent": ua,
            "X-Timeout": 20000
        },

    }
    return fetch(url, deepMerge(defaultOptions, options))
}

async function home() {
    try {
        const categories = [
            {
                type_id: "3", type_name: "手游", vod_list: [], type_type: 'other',
            },
            {
                type_id: "1", type_name: "网游", vod_list: [], type_type: 'other',
            },
            {
                type_id: "2", type_name: "单机", vod_list: [], type_type: 'other',
            },
            {
                type_id: "8", type_name: "娱乐", vod_list: [], type_type: 'other',
            }
        ]
        // for(let i = 0,len = categories.length; i< len; i++) {
        // 	const cate = categories[i]
        // 	const subs = await getCategoryRooms(cate.type_id)
        // 	cate.vod_list = subs.list
        // }

        return success(categories)
    } catch (e) {
        return error(e.message)
    }
}

async function cate(type_id) {
    try {
        const categories = []
        console.log('fetch start', JSON.stringify({type_id}))
        const subs = await getSubCategores(type_id);
        console.log('fetch end', JSON.stringify(subs))
        // 每次10个并发请求
        const limt = pLimit(10);
        const queue = []
        for (let i = 0, len = subs.length; i < len; i++) {
            const sub = subs[i]
            const cate = {
                type_id: sub.id,
                type_name: sub.vod_name,
                vod_list: []
            }
            // queue.push(limt(() => getCategoryRooms(cate.type_id)))
            // cate.vod_list = rs.list
            categories.push(cate)
        }

        // if (queue.length) {
        //     const resQueue = await Promise.allSettled(queue)
        //     resQueue.forEach((rs, i) => {
        //         if (rs.status === 'fulfilled') {
        //             categories[i].vod_list = rs.value?.list ?? []
        //         }
        //     })
        // }

        return success(categories)
    } catch (e) {
        console.log('cate fetcher error', e)
        return error(e.message)
    }
}

async function list(type_id, page = 1) {
    try {
        const rs = await getCategoryRooms(type_id, page)
        return success(rs);

    } catch (e) {
        return error(e.message)
    }
}

async function search(keyword, page = 1, pagesize = 20) {
    try {
        const params = new URLSearchParams({
            "m": "Search",
            "do": "getSearchContent",
            "q": keyword,
            "uid": 0,
            "v": 4,
            "typ": -5,
            "livestate": 0,
            "rows": pagesize,
            "start": (page - 1) * 20,
        })
        const response = await http(`https://search.cdn.huya.com/?${params.toString()}`)
        const result = await response.json();
        // fs.writeFileSync('./temp/search.json', JSON.stringify(result, null, 4));

        const items = [];

        for (const item of result.response["3"].docs) {
            let cover = item.game_screenshot.toString();
            if (!cover.includes("?")) {
                cover += "?x-oss-process=style/w338_h190&";
            }

            let title = item.game_introduction?.toString() || "";
            if (title === "") {
                title = item.game_roomName?.toString() || "";
            }

            const roomItem = {
                vod_id: item.room_id.toString(),
                vod_name: title,
                vod_pic: cover,
                vod_avatar: item.game_avatarUrl180,
                vod_actor: item.game_nick.toString(),
                vod_blurb: item.game_introduction,
                online: parseInt(item.game_total_count.toString()) || 0,
                direction: direction.horizontal
            };
            items.push(roomItem);
        }
        const total = result["response"]["3"]["numFound"];
        return success({
            pages: Math.ceil(total / pagesize),
            total,
            page,
            list: items,
        })
    } catch (e) {
        return error(e.message)
    }

}

async function detail({ vod_id, roomId }) {
    try {
        const roomInfo = await getRoomInfo(vod_id || roomId);
        const tLiveInfo = roomInfo?.roomInfo?.tLiveInfo || {};
        const tProfileInfo = roomInfo?.roomInfo?.tProfileInfo || {};

        // 设置 title
        let title = tLiveInfo.sIntroduction || "";
        if (!title) {
            title = tLiveInfo.sRoomName || "";
        }

        const huyaLines = [];
        const huyaBiterates = [];

        // 处理可用线路
        const lines = tLiveInfo?.tLiveStreamInfo?.vStreamInfo?.value || [];
        lines.forEach((item) => {
            const sFlvUrl = item.sFlvUrl || "";
            if (sFlvUrl) {
                huyaLines.push({
                    line: sFlvUrl,
                    lineType: "flv",
                    flvAntiCode: item.sFlvAntiCode || "",
                    hlsAntiCode: item.sHlsAntiCode || "",
                    streamName: item.sStreamName || "",
                });
            }
        });

        // 处理清晰度选项
        const biterates = tLiveInfo?.tLiveStreamInfo?.vBitRateInfo?.value || [];
        biterates.forEach((item) => {
            const name = item.sDisplayName || "";
            if (!name.includes("HDR")) {
                huyaBiterates.push({
                    bitRate: item.iBitRate,
                    name: name,
                });
            }
        });

        // 提取 topSid 和 subSid
        const topSid = roomInfo.topSid || 0;
        const subSid = roomInfo.subSid || 0;

        // 构建 LiveRoomDetail 对象

        const playurl = `https:${base64(roomInfo?.roomProfile?.liveLineUrl || "")}`

        const uid = getUid({ t: 13, e: 10 })

        const qualitys = await getPlayQualities({
            bitRates: huyaBiterates,
            lines: huyaLines,
            uid
        })

        return success({
            vod_pic: tLiveInfo.sScreenshot || "",
            online: tLiveInfo.lTotalCount || 0,
            roomId: tLiveInfo.lProfileRoom?.toString() || "",
            vod_id: tLiveInfo.lProfileRoom?.toString() || "",
            vod_name: title,
            vod_actor: tProfileInfo.sNick || "",
            vod_avatar: tProfileInfo.sAvatar180 || "",
            vod_blurb: tLiveInfo.sIntroduction || "",
            notice: roomInfo.welcomeText || "",
            status: roomInfo?.roomInfo?.eLiveStatus === 2,
            vod_sources: [{
                url: playurl,
                uid,
                vod_play_list: {
                    url_count: qualitys.length,
                    urls: qualitys.map(qua => {
                        return {
                            name: qua.quality,
                            urls: qua.data
                        }
                    })
                }

            }],
            danmakuData: {
                ayyuid: tLiveInfo.lYyid || 0,
                topSid: topSid,
                subSid: subSid,
            },
            url: `https://www.huya.com/${vod_id ? vod_id : roomId}`,
        });
    } catch (e) {
        return error(e.message)
    }

}

async function getSubCategores(id) {
    const response = await http(`https://live.cdn.huya.com/liveconfig/game/bussLive?bussType=${id}`)

    const rs = await response.json();
    const subs = []
    const list = rs.data ?? []

    // fs.writeFileSync(`./temp/sub_${id}.json`, JSON.stringify(rs, null, 4))

    let gid = "";
    list.forEach(item => {
        if (toString.call(item["gid"]) === '[object Object]') {
            gid = item["gid"]["value"].toString().split(",")[0];
        } else {
            gid = item["gid"];
        }


        subs.push({
            id: gid,
            vod_name: item["gameFullName"],
            parentId: id,
            vod_pic: "https://huyaimg.msstatic.com/cdnimage/game/${gid}-MS.jpg",
            direction: direction.horizontal
        });
    })
    return subs;
}

async function getCategoryRooms(type_id, page = 1) {
    const response = await http(`https://www.huya.com/cache.php?m=LiveList&do=getLiveListByPage&tagAll=0&gameId=${type_id}&page=${page}`)

    const rs = await response.json();
    // fs.writeFileSync(`./temp/list_${type_id}.json`, JSON.stringify(rs, null, 4))
    const items = []

    const list = rs?.data?.datas || [];


    list.forEach(item => {
        let cover = item.screenshot;
        if (cover.includes("?")) {
            cover += "?x-oss-process=style/w338_h190&";
        }

        let title = item.introduction ?? "";
        if (!String(title).trim()) {
            title = item.roomName ?? "";
        }
        items.push({
            roomId: item.profileRoom,
            vod_id: item.profileRoom,
            vod_name: title,
            vod_pic: cover,
            vod_actor: item.nick,
            vod_avatar: item.avatar180,
            vod_blurb: item.introduction,
            online: parseInt(item.totalCount, 10),
            direction: direction.horizontal
        })
    })
    return {
        pages: rs.data.totalPage,
        page: rs.data.page,
        total: rs.data.totalCount,
        list: items
    }
}

async function getRoomInfo(id) {
    const response = await http(`https://m.huya.com/${id}`)

    const resultText = await response.text();
    // 从 resultText 中匹配包含 HNF_GLOBAL_INIT 的脚本内容
    const textMatch = resultText.match(/window\.HNF_GLOBAL_INIT\s*=\s*\{[\s\S]*?\}[\s\S]*?<\/script>/);
    let text = textMatch ? textMatch[0] : null;

    // 将 JSON 文本解析为对象
    let jsonObj = {}
    if (text) {
        // 去掉前缀 "window.HNF_GLOBAL_INIT =" 和 "</script>"
        let jsonText = text
            .replace(/window\.HNF_GLOBAL_INIT\s*=\s*/, '')
            .replace(/<\/script>/, "")
            .replace(/function.*?\(.*?\)\s*\{[\s\S]*?\}/g, '""'); // 用空字符串替换 function(...) {...} 内容
        try {
            jsonObj = JSON.parse(jsonText);
        } catch (e) {
            jsonObj = {};
        }

        // 提取 topSid 和 subSid
        const topSidMatch = resultText.match(/lChannelId":([0-9]+)/);
        const subSidMatch = resultText.match(/lSubChannelId":([0-9]+)/);

        const topSid = topSidMatch ? parseInt(topSidMatch[1], 10) : 0;
        const subSid = subSidMatch ? parseInt(subSidMatch[1], 10) : 0;

        // 将 topSid 和 subSid 添加到 jsonObj 中
        jsonObj["topSid"] = topSid;
        jsonObj["subSid"] = subSid;

    }

    return jsonObj
}

function deepMerge(target, source) {
    if (typeof target !== 'object' || target === null) return target;
    if (typeof source !== 'object' || source === null) return target;

    for (const key of Object.keys(source)) {
        if (source[key] instanceof Array) {
            // 如果是数组，直接替换
            target[key] = source[key].slice();
        } else if (source[key] instanceof Object) {
            // 如果是对象，递归合并
            target[key] = deepMerge(target[key] || {}, source[key]);
        } else {
            // 如果是原始值，直接赋值
            target[key] = source[key];
        }
    }

    return target;
}

function getUid({ t, e } = {}) {
    const n = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
    const o = new Array(36).fill("");

    if (t != null) {
        // 如果提供了参数 t，则生成前 t 个随机字符
        for (let i = 0; i < t; i++) {
            o[i] = n[Math.floor(Math.random() * (e ?? n.length))];
        }
    } else {
        // 否则，生成一个标准格式的 UUID
        o[8] = o[13] = o[18] = o[23] = "-";
        o[14] = "4";
        for (let i = 0; i < 36; i++) {
            if (!o[i]) {
                const r = Math.floor(Math.random() * 16);
                o[i] = n[i === 19 ? (3 & r) | 8 : r];
            }
        }
    }

    return o.join("");
}

function base64(text) {
    return Utf8.stringify(Base64.parse(text));
}

async function getPlayQualities(detail) {
    const qualities = [];
    const urlData = detail;

    // 如果 bitRates 为空，设置默认值
    if (!urlData.bitRates || urlData.bitRates.length === 0) {
        urlData.bitRates = [
            { name: "原画", bitRate: 0 },
            { name: "高清", bitRate: 2000 }
        ];
    }

    // 如果 lines 为空，可按需求添加默认线路
    /*
    if (!urlData.lines || urlData.lines.length === 0) {
        urlData.lines = [
        { line: "tx.flv.huya.com", lineType: "flv" },
        { line: "bd.flv.huya.com", lineType: "flv" },
        { line: "al.flv.huya.com", lineType: "flv" },
        { line: "hw.flv.huya.com", lineType: "flv" }
        ];
    }
    */

    // 遍历 bitRates 和 lines，构建质量对象
    for (const item of urlData.bitRates) {
        const urls = [];
        for (const line of urlData.lines) {
            let src = `${line.line}/${line.streamName}`;

            // 根据 lineType 添加正确的后缀
            if (line.lineType === "flv") {
                src += ".flv";
            } else if (line.lineType === "hls") {
                src += ".m3u8";
            }

            // 处理防盗链参数
            const parms = processAnticode(
                line.lineType === "flv" ? line.flvAntiCode : line.hlsAntiCode,
                urlData.uid,
                line.streamName
            );
            src += `?${parms}`;

            // 如果有比特率，添加比特率参数
            if (item.bitRate > 0) {
                src += `&ratio=${item.bitRate}`;
            }

            urls.push(src);
        }

        // 添加到 qualities
        qualities.push({
            data: urls,
            quality: item.name
        });
    }

    // 返回 Promise，模拟异步返回
    return Promise.resolve(qualities);
}

function processAnticode(anticode, uid, streamname) {
    // 解析查询字符串
    const query = Object.fromEntries(new URLSearchParams(anticode));

    query["t"] = "102";
    query["ctype"] = "tars_mp";

    // 获取当前时间并转换为16进制字符串
    const wsTime = Math.floor(Date.now() / 1000 + 21600).toString(16);
    const seqId = (Date.now() + parseInt(uid)).toString();

    // 解码并解析 `fm`
    const fm = base64(decodeURIComponent(query['fm']));
    const wsSecretPrefix = fm.split('_')[0];

    // 计算 `wsSecretHash`
    const wsSecretHash = md5(`${seqId}|${query["ctype"]}|${query["t"]}`);

    // 计算 `wsSecret`
    const wsSecret = md5(`${wsSecretPrefix}_${uid}_${streamname}_${wsSecretHash}_${wsTime}`);

    // 构建查询参数
    const params = new URLSearchParams({
        wsSecret: wsSecret,
        wsTime: wsTime,
        seqid: seqId,
        ctype: query["ctype"],
        ver: "1",
        fs: query["fs"] || "",
        sphdcdn: query["sphdcdn"] || "",
        sphdDC: query["sphdDC"] || "",
        sphd: query["sphd"] || "",
        exsphd: query["exsphd"] || "",
        uid: uid,
        uuid: getUUid(), // 假设 getUUid() 是一个返回 uuid 的函数
        t: query["t"],
        sv: "2401310322"
    });

    return params.toString();
}

function md5(text) {
    return MD5(text).toString();
}

function getUUid() {
    const currentTime = Date.now();
    const randomValue = Math.floor(Math.random() * 4294967295);
    const result = ((currentTime % 10000000000) * 1000 + randomValue) % 4294967295;
    return result.toString();
}


async function play(url) {
    return Promise.resolve(success(url))
}

module.exports.home = home
module.exports.cate = cate
module.exports.list = list
module.exports.search = search
module.exports.detail = detail
module.exports.play = play