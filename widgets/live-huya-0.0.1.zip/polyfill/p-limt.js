var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateWrapper = (obj, member, setter, getter) => ({
  set _(value) {
    __privateSet(obj, member, value, setter);
  },
  get _() {
    return __privateGet(obj, member, getter);
  }
});
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// node_modules/.pnpm/yocto-queue@1.1.1/node_modules/yocto-queue/index.js
var Node, _head, _tail, _size, Queue;
var init_yocto_queue = __esm({
  "node_modules/.pnpm/yocto-queue@1.1.1/node_modules/yocto-queue/index.js"() {
    Node = class {
      constructor(value) {
        __publicField(this, "value");
        __publicField(this, "next");
        this.value = value;
      }
    };
    Queue = class {
      constructor() {
        __privateAdd(this, _head);
        __privateAdd(this, _tail);
        __privateAdd(this, _size);
        this.clear();
      }
      enqueue(value) {
        const node = new Node(value);
        if (__privateGet(this, _head)) {
          __privateGet(this, _tail).next = node;
          __privateSet(this, _tail, node);
        } else {
          __privateSet(this, _head, node);
          __privateSet(this, _tail, node);
        }
        __privateWrapper(this, _size)._++;
      }
      dequeue() {
        const current = __privateGet(this, _head);
        if (!current) {
          return;
        }
        __privateSet(this, _head, __privateGet(this, _head).next);
        __privateWrapper(this, _size)._--;
        return current.value;
      }
      peek() {
        if (!__privateGet(this, _head)) {
          return;
        }
        return __privateGet(this, _head).value;
      }
      clear() {
        __privateSet(this, _head, void 0);
        __privateSet(this, _tail, void 0);
        __privateSet(this, _size, 0);
      }
      get size() {
        return __privateGet(this, _size);
      }
      *[Symbol.iterator]() {
        let current = __privateGet(this, _head);
        while (current) {
          yield current.value;
          current = current.next;
        }
      }
    };
    _head = new WeakMap();
    _tail = new WeakMap();
    _size = new WeakMap();
  }
});

// index.js
var p_limit_6_1_exports = {};
__export(p_limit_6_1_exports, {
  default: () => pLimit
});
function pLimit(concurrency) {
  validateConcurrency(concurrency);
  const queue = new Queue();
  let activeCount = 0;
  const resumeNext = () => {
    if (activeCount < concurrency && queue.size > 0) {
      queue.dequeue()();
      activeCount++;
    }
  };
  const next = () => {
    activeCount--;
    resumeNext();
  };
  const run = (function_, resolve, arguments_) => __async(this, null, function* () {
    const result = (() => __async(this, null, function* () {
      return function_(...arguments_);
    }))();
    resolve(result);
    try {
      yield result;
    } catch (e) {
    }
    next();
  });
  const enqueue = (function_, resolve, arguments_) => {
    new Promise((internalResolve) => {
      queue.enqueue(internalResolve);
    }).then(
      run.bind(void 0, function_, resolve, arguments_)
    );
    (() => __async(this, null, function* () {
      yield Promise.resolve();
      if (activeCount < concurrency) {
        resumeNext();
      }
    }))();
  };
  const generator = (function_, ...arguments_) => new Promise((resolve) => {
    enqueue(function_, resolve, arguments_);
  });
  Object.defineProperties(generator, {
    activeCount: {
      get: () => activeCount
    },
    pendingCount: {
      get: () => queue.size
    },
    clearQueue: {
      value() {
        queue.clear();
      }
    },
    concurrency: {
      get: () => concurrency,
      set(newConcurrency) {
        validateConcurrency(newConcurrency);
        concurrency = newConcurrency;
        queueMicrotask(() => {
          while (activeCount < concurrency && queue.size > 0) {
            resumeNext();
          }
        });
      }
    }
  });
  return generator;
}
function validateConcurrency(concurrency) {
  if (!((Number.isInteger(concurrency) || concurrency === Number.POSITIVE_INFINITY) && concurrency > 0)) {
    throw new TypeError("Expected `concurrency` to be a number from 1 and up");
  }
}
var init_p_limit_6_1 = __esm({
  "index.js"() {
    init_yocto_queue();
  }
});

// p-limit.cjs
var pLimit2 = (init_p_limit_6_1(), __toCommonJS(p_limit_6_1_exports)).default;
module.exports = pLimit2;
