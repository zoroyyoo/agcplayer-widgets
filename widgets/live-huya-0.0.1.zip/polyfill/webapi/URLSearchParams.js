class URLSearchParams {
    constructor(init = "") {
        this.params = new Map();

        if (typeof init === "string") {
            this._parse(init);
        } else if (typeof init === "object") {
            for (let [key, value] of Object.entries(init)) {
                this.append(key, value);
            }
        }
    }

    _parse(queryString) {
        const pairs = queryString.replace(/^\?/, "").split("&");
        for (let pair of pairs) {
            if (pair) {
                const [key, value] = pair.split("=").map(decodeURIComponent);
                this.append(key, value);
            }
        }
    }

    append(key, value) {
        if (this.params.has(key)) {
            this.params.get(key).push(value);
        } else {
            this.params.set(key, [value]);
        }
    }

    delete(key) {
        this.params.delete(key);
    }

    get(key) {
        return this.params.has(key) ? this.params.get(key)[0] : null;
    }

    getAll(key) {
        return this.params.has(key) ? this.params.get(key) : [];
    }

    has(key) {
        return this.params.has(key);
    }

    set(key, value) {
        this.params.set(key, [value]);
    }

    toString() {
        const queryArray = [];
        for (let [key, values] of this.params) {
            for (let value of values) {
                queryArray.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
            }
        }
        return queryArray.join("&");
    }
}