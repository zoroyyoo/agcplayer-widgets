function success(data) {
    return {
        code: 0,
        data,
    }
}

function error(msg, code = -1) {
    return {
        code,
        msg,
    }
}

module.exports.success = success;
module.exports.error = error;