const { success, error } = require('./lib/response');
const { request } = require('./lib/request.js')
const select = require("./lib/xpath.js");
const dom = require("./lib/xmldom/index.js").DOMParser;
const parse5 = require("./lib/parse5.min.js");
const { writeFileSync, readFileSync  } = require('./lib/debug.js')
const { unescapeEntity } = require('./lib/index.js')

const direction = {
    horizontal: "horizontal",
    vertical: "vertical",
};

/**
 * 获取首页分类
 * @returns 
 */
async function home() {
    try {
        const response = await request('https://www.animeworld.so/')
        const notStandardHtml = await response.text()
        writeFileSync('home.html', notStandardHtml)
        // const notStandardHtml = readFileSync('home.html')
         // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
         const doc5 = parse5.parseFragment(notStandardHtml);
         const html = parse5.serialize(doc5);
 
         const document = new dom().parseFromString(html, "text/html");

         const result = []
         
         const $slides = select(
             document,
             "//div[contains(@id, 'swiper-container')]/div[contains(@class, 'swiper-wrapper')]/div[contains(@class, 'item')]"
         )

         // 轮播图，推荐
         if($slides.length) {
            const cate = {
                type_name: "Recommend",
                vod_list: []
            }
             $slides.forEach($item => {
                const $link = select($item, './/a')[0];
                const vod_id = select($link, "./@href")[0]?.value?.trim();
                const vod_name = unescapeEntity(select($link, "./@title")[0]?.value?.trim());
                const pic_str = select($item, "./@style")[0]?.value?.trim();
                const regex = /url\(\s*['"]?(.*?)['"]?\s*\)/i;
                const match = pic_str.match(regex);
                let vod_pic = "";
                if (match && match[1]) {
                    vod_pic = match[1];
                }

                cate.vod_list.push({
                    vod_id,
                    vod_name,
                    vod_pic,
                    direction: direction.vertical
                })
             })
             result.push(cate)
         }

         const $main =  select(
            document,
            "//div[contains(@id, 'main')]/div[contains(@class, 'content')]"
        )[0]
         // 最近更新 Latest Episodes
         const $hotnew  = select(
            $main,
            "./div[contains(@class, 'hotnew')]")[0]
        if($hotnew) {
            const $firstContent =  select($hotnew, "./div[contains(@class, 'widget-body')]/div[contains(@class, 'content')]")[0];
            const $items = select($firstContent, ".//div[contains(@class, 'item')]")
            if($items.length) {
                const cate = {
                    type_name: "Latest Episodes",
                    vod_list: []
                }
                 $items.forEach($item => {
                    const $link1 = select($item, './/a')[0];
                    const $link2 = select($item, './/a')[1];

                    const vod_id = select($link1, "./@href")[0]?.value?.trim();
                    const vod_name = unescapeEntity(select($link2, "./@title")[0]?.value?.trim());
                    const vod_pic = select($link1, "./img/@src")[0]?.value?.trim();
                    const vod_remarks = select($link1, ".//div[contains(@class, 'ep')]/text()")?.toString()?.trim();

                    cate.vod_list.push({
                        vod_id,
                        vod_name,
                        vod_pic,
                        vod_remarks,
                        direction: direction.vertical
                    })
                 })
                 result.push(cate)
            }
        }

        const $widgets = select($main, "./div[contains(@class, 'widget')]");
        if($widgets?.length) {
            $widgets.forEach(($widget, i) => {

                // anime in corso
                // Uscite Inverno 2025
                if(i === 3 || i === 5) {
                    const $title = select($widget, "./div[contains(@class, 'widget-title')]")[0]
                    const type_name = unescapeEntity(select($title, "./div[contains(@class, 'title')]/text()")?.toString()?.trim())
                    const type_id = select($title, "./a[contains(@class, 'more')]/@href")[0]?.value?.trim()
                    if(type_name && type_id) {
                        const cate = {
                            type_id,
                            type_name,
                            vod_list: []
                        }
            
                        const $items = select($widget, "./div[contains(@class, 'widget-body')]//div[contains(@class, 'item')]")
                        $items.forEach($item => {
                            const $link1 = select($item, './/a')[0];
                            const $link2 = select($item, './/a')[1];
            
                            const vod_id = select($link1, "./@href")[0]?.value?.trim();
                            const vod_name = unescapeEntity(select($link2, "./@title")[0]?.value?.trim());
                            const vod_pic = select($link1, "./img/@src")[0]?.value?.trim();
                            const vod_remarks = select($link1, ".//div[contains(@class, 'ep')]/text()")?.toString()?.trim();
            

                            cate.vod_list.push({
                                vod_id,
                                vod_name,
                                vod_pic,
                                vod_remarks,
                                direction: direction.vertical
                            })
                         })
        
                         result.push(cate)
                    }
                }
            })
        }
        writeFileSync('home.json', result)
        return success(result)
    } catch (e) {
        console.error(e)
        return error(e.message)
    }
}

async function detail({ vod_id}) {
    try {
        const url = vod_id.startsWith('http') ? vod_id : `https://www.animeworld.so${vod_id}`
        const response = await request(url)
        const notStandardHtml = await response.text()
        writeFileSync('detail.html', notStandardHtml)
        // const notStandardHtml = readFileSync('detail.html')
         // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
         const doc5 = parse5.parseFragment(notStandardHtml);
         const html = parse5.serialize(doc5);
 
         const document = new dom().parseFromString(html, "text/html");

         const $main =  select( document, "//div[contains(@id, 'main')]/div[contains(@class, 'content')]")[0]
         
         let vod_actor = ''
         let vod_area = ''
         let vod_class = ''
         let vod_lang = ''
         let vod_time = ''
         let vod_year = ''
         let vod_remarks = ''
 
         let vod_name = "";
         let vod_pic = "";
         let vod_content = "";
 
         const vod_sources = []

         // info
         const $info =  select($main, './/div[contains(@class, "widget") and contains(@class, "info")]')[0]

         if($info) {
            const raw_name = select($info, ".//div[contains(@class, 'head')]//h2[contains(@class, 'title')]/@data-jtitle")[0]?.value?.trim()
            vod_name = unescapeEntity(raw_name);
            console.log('vod_name',raw_name, vod_name)
            vod_pic = select($info, ".//div[contains(@class, 'thumb')]/img/@src")[0]?.value?.trim();
            vod_content = unescapeEntity(select($info, ".//div[contains(@class, 'desc')]/text()")?.toString()?.trim());

            const $metas = select($info, ".//dl[contains(@class, 'meta')]/dd")
            if($metas.length) {
                $metas.forEach(($meta,i) => {
                    switch (i) {
                        // class
                        case 0:
                            vod_class = select($meta, "./text()")?.toString()?.trim();
                            break;
                        case 1:
                            vod_lang = select($meta, './a/text()')?.toString()?.trim();
                            break;
                        case 2:
                            const raw_time = select($meta, "./text()")?.toString()?.trim()
                            // vod_time = parseDateToTimestamp(raw_time);
                            vod_time = raw_time
                            // console.log('time', raw_time, vod_time)
                            break;
                        case 3:
                            vod_year = select($meta, './a/text()')?.toString()?.trim().match(/\b\d{4}\b/)?.[0]
                            break;
                        case 7: 
                            vod_remarks = select($meta, './a/text()')?.toString()?.trim();
                            break;
                    }
                })
            }
         }
         
         // sources
         const $servers = select($main, './/div[contains(@id, "animeId")]')[0]
         if($servers) {
             const $widgetTitle =  select($servers, ".//div[contains(@class, 'widget-title')]")[0]
             const $widgetBody =  select($servers, ".//div[contains(@class, 'widget-body')]")[0]
             const $sources = select($widgetTitle, "./span[contains(@class, 'servers-tabs')]/span[contains(@class, 'server-tab')]")
            if($widgetTitle && $widgetBody) {
                $sources.forEach(($source) => {
                    const source_name = select($source, "./text()")?.toString()?.trim();
                    const id = select($source, './@data-name')[0]?.value?.trim();
    
                    const source = {
                        source_name: source_name,
                        vod_play_list: {
                            url_count: 0,
                            urls: []
                        }
                    }

                    const $nids = select($widgetBody, `./div[contains(@class, 'server') and contains(@data-name, '${id}')]//li[contains(@class, 'episode')]`);
                    if( $nids.length) {
                        source.vod_play_list.url_count = $nids.length

                        $nids.forEach($nid => {
                            const url = {
                                name: '',
                                url: '',
                            }
                            const $link = select($nid, './a')[0]
                            const href = select($link, "./@href")[0]?.value?.trim();
                            const name = select($link, './text()')?.toString()?.trim();
                            url.name = name
                            url.url = !href.startsWith('http') ? `https://www.animeworld.so${href}` : href
                            source.vod_play_list.urls.push(url);
                        })

                        vod_sources.push(source)
                    }
                    
                })
            }
         }


         const $similars = select($main, './/div[contains(@class, "interesting")]/div[contains(@class, "item")]')
         const similar = []
         if($similars.length) {
            $similars.forEach($item => {
                const $link1 = select($item, './/a')[0];
                const $link2 = select($item, './/a')[1];

                const vod_id = select($link1, "./@href")[0]?.value?.trim();
                const vod_name = unescapeEntity(select($link2, "./@title")[0]?.value?.trim());
                const vod_pic = select($link1, "./img/@src")[0]?.value?.trim();
                const vod_remarks = select($link1, ".//div[contains(@class, 'ep')]/text()")?.toString()?.trim();

                similar.push({
                    vod_id,
                    vod_name,
                    vod_pic,
                    vod_remarks,
                    direction: direction.vertical
                })
             })
         }

         const detail = {
            vod_actor,
            vod_area,
            vod_class,
            vod_content,
            vod_id,
            vod_lang,
            vod_name,
            vod_pic,
            vod_time,
            vod_year,
            vod_remarks,
            vod_sources,
            similar
        }
        writeFileSync('detail_done.json', detail)
        return success(detail)
    } catch(e) {
        console.log(`detail=> ${e.stack}`)
        return error(e.message);
    }
}

async function play({url}) {
    try {
        const playUrl = await getPlayInfo(url)
        return success(playUrl)
    } catch(e) {
        return error(e.message)
    }
}

async function list(type_id, page) {
    try {
        const response = await request(`${type_id}?page=${page}`)
        const notStandardHtml = await response.text()
        writeFileSync('list.html', notStandardHtml)
        // const notStandardHtml = readFileSync('home.html')
         // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
         const doc5 = parse5.parseFragment(notStandardHtml);
         const html = parse5.serialize(doc5);
 
         const document = new dom().parseFromString(html, "text/html");

         let $main =  select(
            document,
            "//div[contains(@id, 'main')]/div[contains(@class, 'content')]")[0]
        if(!$main) {
            $main =  select(
                document,
                "//div[contains(@id, 'body')]/div[contains(@class, 'container')]")[0]
        }
        const list = [];
        let pages = 1;
        if($main) {
            const $widgetBody =  select($main, "./div[contains(@class, 'widget')]/div[contains(@class, 'widget-body')]")[0]
            if($widgetBody) {
                const $list = select($widgetBody, ".//div[contains(@class, 'item')]")
                if($list.length) {
                   $list.forEach($item => {
                       const $link1 = select($item, './/a')[0];
                       const $link2 = select($item, './/a')[1];
       
                       const vod_id = select($link1, "./@href")[0]?.value?.trim();
                       const vod_name = unescapeEntity(select($link2, "./@data-jtitle")[0]?.value?.trim());
                       const vod_pic = select($link1, "./img/@src")[0]?.value?.trim();
                    //    const vod_remarks = select($link1, ".//div[contains(@class, 'ep')]/text()")?.toString()?.trim();
       
                       list.push({
                           vod_id,
                           vod_name,
                           vod_pic,
                           vod_remarks: '',
                           direction: direction.vertical
                       })
                    })
                }
    
                const pageStr = select($main, ".//form[contains(@id, 'paging-form')]//span[contains(@class, 'total')]/text()")?.toString()?.trim();
                if(pageStr) {
                    pages = Number(pageStr)
                }
            }
        }
        const result = {
            page,
            pages,
            list
        }
        writeFileSync('list.json', result)
        return success(result)
    } catch (e) {
        console.error(e)
        return error(e.message)
    }
}

async function search(keyword, page) {
    try {
        const response = await request(`https://www.animeworld.so/search?keyword=${keyword}&page=${page}`)
        const notStandardHtml = await response.text()
        writeFileSync('search.html', notStandardHtml)
        // const notStandardHtml = readFileSync('home.html')
         // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
         const doc5 = parse5.parseFragment(notStandardHtml);
         const html = parse5.serialize(doc5);
 
         const document = new dom().parseFromString(html, "text/html");

         const $main =  select(
            document,
            "//div[contains(@id, 'main')]/div[contains(@class, 'content')]")[0]

        const list = [];
        let pages = 1;
        if($main) {
            const $widgetBody =  select($main, "./div[contains(@class, 'widget')]/div[contains(@class, 'widget-body')]")[0]
            if($widgetBody) {
                const $list = select($widgetBody, "./div[contains(@class, 'film-list')]/div[contains(@class, 'item')]")
                if($list.length) {
                   $list.forEach($item => {
                       const $link1 = select($item, './/a')[0];
                       const $link2 = select($item, './/a')[1];
       
                       const vod_id = select($link1, "./@href")[0]?.value?.trim();
                       const vod_name = unescapeEntity(select($link2, "./@data-jtitle")[0]?.value?.trim());
                       const vod_pic = select($link1, "./img/@src")[0]?.value?.trim();
                    //    const vod_remarks = select($link1, ".//div[contains(@class, 'ep')]/text()")?.toString()?.trim();
       
                       list.push({
                           vod_id,
                           vod_name,
                           vod_pic,
                           vod_remarks: '',
                           direction: direction.vertical
                       })
                    })
                }
    
                const pageStr = select($main, ".//form[contains(@id, 'paging-form')]//span[contains(@class, 'total')]/text()")?.toString()?.trim();
                if(pageStr) {
                    pages = Number(pageStr)
                }
            }
        }
        const result = {
            page,
            pages,
            list
        }
        writeFileSync('search.json', result)
        return success(result)
    } catch (e) {
        console.error(e)
        return error(e.message)
    }
}

/**
 * get play info
{
    "grabber": "https://srv16-suisen.sweetpixel.org/DDL/ANIME/BleachSennenKessen-henSoukoku-tan/BleachSennenKessen-henSoukoku-tan_Ep_01_SUB_ITA.mp4",
    "name": "LjIi2v",
    "target": "/api/episode/serverPlayerAnimeWorld?id=LjIi2v"
}
 */
async function getPlayInfo(token) {
    try {
        const response = await request(token)
        const html = await response.text()
        const key = new URL(token).pathname.split('/').pop();
        if(!key) throw new Error('获取分集token失败')
        const response2 = await request(`https://www.animeworld.so/api/episode/info?id=${key}&alt=0`)
        const json = await response2.json();
        if(!json?.grabber) {
            throw new Error('url empty')
        }
        return json.grabber
    } catch(e) {   
        throw new Error(`获取播放信息失败 => ${e.message}`)
    }
}

// 解析意大利日期为时间戳，单位秒
function parseDateToTimestamp(str) {
    let dateStr = str
    // 映射常见月份 (如果日期格式带有特定语言的月份)
    const monthMap = {
        Gennaio: "January",
        Febbraio: "February",
        Marzo: "March",
        Aprile: "April",
        Maggio: "May",
        Giugno: "June",
        Luglio: "July",
        Agosto: "August",
        Settembre: "September",
        Ottobre: "October",
        Novembre: "November",
        Dicembre: "December"
    };

    // 替换月份
    for (const [key, value] of Object.entries(monthMap)) {
        if (dateStr.includes(key)) {
            dateStr = dateStr.replace(key, value);
            break;
        }
    }

    // 尝试用 Date 对象解析日期
    try {
        const isoDate = parseToISO(dateStr);
        if(isoDate) {
            const date = new Date(isoDate);
            if (!isNaN(date)) {
                return parseInt(date.getTime()/1000); 
            }
        }
    } catch (error) {
        console.error("解析日期失败:", error);
    }

    return str;
}

function parseToISO(dateStr) {
    const regex = /(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/;
    const monthMap = {
        January: "01", February: "02", March: "03", April: "04", May: "05", June: "06",
        July: "07", August: "08", September: "09", October: "10", November: "11", December: "12"
    };

    const match = regex.exec(dateStr);
    if (match) {
        const day = match[1].padStart(2, "0");
        const month = monthMap[match[2]];
        const year = match[3];
        if (month) {
            return `${year}-${month}-${day}T00:00:00Z`; // 转换为 ISO 8601 格式
        }
    }
    return null;
}

module.exports.home = home
module.exports.detail = detail
module.exports.play = play
module.exports.list = list
module.exports.search = search
