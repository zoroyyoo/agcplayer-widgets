module.exports = {
    home: () => "https://gimy.tv/",
    list: (type_id, page) => `https://gimy.tv/genre/${type_id}---${page}.html`,
    detail: (video_id)=> `https://gimy.tv/vod/${video_id}.html`,
    search: (keyword, page)  => `https://gimy.tv/search/${keyword}----------${page}---.html`
}