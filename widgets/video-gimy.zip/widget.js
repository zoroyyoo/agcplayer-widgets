const select = require('./lib/xpath.js')
const dom = require('./lib/xmldom/index.js').DOMParser
const parse5 = require('./lib/parse5.min.js')
const config = require('./config.js')
const { success, error } = require('./lib/response.js')
const { request } = require('./lib/request.js');
const { unescapeEntity } = require('./lib/index.js')
// const fs = require('fs')

async function home() {
    try {
        const resposne = await request(config.home())
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();
        // fs.writeFileSync('./home.html', notStandardHtml)
        // const notStandardHtml = fs.readFileSync('./home.html', { encoding: 'utf8' })

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');
        const $container = select(document, "//div[contains(@class, 'container')]")[0]
        $sections = select($container, "./div/div[contains(@class, 'myui-panel')]")
        const result = []
        $sections.forEach(($row, i) => {
            const $header = select($row, ".//div[contains(@class, 'myui-panel__head')]")[0]
            if (!$header) return;
            const type_name = select($header, "./h3[contains(@class, 'title')]//text()")?.toString()?.trim()
            const typeLink = select($header, ".//a[contains(@class, 'more')]//@href")[0]?.value
            let type_id
            if (typeLink) {
                const matchVal = typeLink.match(/\/browse\/(\d+).html/)
                if (matchVal) {
                    type_id = matchVal[1]
                }
            }
            if (typeof type_id === 'undefined') return

            type_id = Number(type_id)

            const vod_list = []

            const $items = select($row, ".//div[contains(@class,'myui-vodlist__box')]")
            $items.forEach(($item, i) => {
                const href = select($item, "./a/@href")[0]?.value
                const vod_name = select($item, "./a/@title")[0]?.value
                const vod_pic = select($item, "./a/@data-original")[0]?.value

                const vod_remarks = select($item, "./a/span[contains(@class, 'pic-text')]//text()")?.toString()?.trim()
                let vod_id;
                const matchVal = href.match(/\/vod\/(\d+)\.html/)
                if (matchVal) {
                    vod_id = matchVal[1]
                }
                if (vod_id) {
                    vod_list.push({
                        type_id,
                        vod_id: Number(vod_id),
                        vod_name,
                        vod_pic,
                        vod_remarks
                    })
                }
            })
            if (vod_list.length) {
                result.push({
                    type_id,
                    type_name,
                    vod_list
                })
            }
        })
        return success(result);
    } catch (e) {
        console.error(e)
        return error(e.message);
    }

}

async function detail({ vod_id }) {
    try {
        const resposne = await request(config.detail(vod_id))
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();

        // fs.writeFileSync('./detail.html', notStandardHtml)
        // const notStandardHtml = fs.readFileSync('./detail.html', { encoding: 'utf8' })

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');
        const $container = select(document, "//div[contains(@class, 'container')]")[0]

        const $info = select($container, ".//div[contains(@class, 'myui-content__detail')]")[0]

        let vod_actor = ''
        let vod_area = ''
        let vod_class = ''
        let vod_lang = ''
        let vod_time = ''
        let vod_year = ''
        let vod_remarks = ''

        let vod_name = "";
        let vod_pic = "";
        let vod_content = "";

        const vod_sources = []

        if ($info) {
            const actor_label = "主演"
            const time_label = "更新"
            const remarks_label = "状态"

            vod_name = unescapeEntity(unescapeEntity((select($info, "./h1[contains(@class, 'title')]/text()") || "").toString())).trim()
            vod_pic = select($container, ".//div[contains(@class, 'myui-content__thumb')]/a/img/@data-original")[0]?.value;

            const $datas = select($info, "./p[contains(@class, 'data')]")
            $datas.forEach(($data,i) => {
                if(i === 0) {
                    const $links = select($data, "./a");
                    vod_class = $links[0] ? select($links[0], './text()')?.toString()?.trim() : ''
                    vod_year = $links[1] ? select($links[1], './text()')?.toString()?.trim() : ''
                }
                const label = select($data, "./span[contains(@class, 'text-muted')]/text()")?.toString()?.trim();

                const isActor = label.includes(actor_label)
                if(isActor) {
                    const actors = []
                    const $actors = select($data, './a')
                    $actors?.forEach(($link) => {
                        const actor = select($link, "./text()")?.toString()?.trim();
                        actor && actors.push(actor)
                    })
                    vod_actor = actors.join(',')
                } else if(label.includes(time_label)) {
                    const t = select($data, './text()')?.toString()?.trim();
                    if(t) {
                        vod_time = t// Math.ceil(new Date(t).getTime()/1000)
                    }
                } else if(label.includes(remarks_label)) {
                    const t = select($data, './text()')?.toString()?.trim();
                    if(t) {
                        vod_remarks = t
                    }
                }
            })
        }

        vod_content = select(document, "//div[contains(@id, 'desc')]//div[contains(@class, 'content')]/p/text()")?.toString()?.trim();

        const $row2 = select($container, "./div[contains(@class, 'row')]")[1]

        const $sources = select($row2, "./div/div[contains(@class, 'myui-panel') and contains(@class, 'myui-panel-bg')]")
        for(let i = 0, len = $sources.length; i< len ;i++) {
            const $source = $sources[i]
            // 遇到desc就结束
            const id = select($source, "./@id")[0]?.value;
            if(id) break;

            const source_name = select($source, ".//div[contains(@class, 'myui-panel__head')]/h3/text()").toString()?.trim()
            if (source_name) {
                const source = {
                    source_name: source_name,
                    vod_play_list: {
                        url_count: 0,
                        urls: []
                    }
                }
                const $links = select($source, './/ul[contains(@class,"myui-content__list")]/li')
                source.vod_play_list.url_count = $links.length
                $links.forEach($link => {
                    const url = {
                        name: '',
                        url: '',
                    }
                    const href = select($link, "./a/@href")[0]?.value?.trim();
                    const name = select($link, './a/text()')?.toString()?.trim();
                    url.name = name
                    url.url = href
                    source.vod_play_list.urls.push(url);
                })

                vod_sources.push(source)
            }
        }

         // 目前发现量子线路的资源有问题，放到资源列表最后
         if(vod_sources[0].source_name === '量子线路') {
            const t0 = vod_sources.shift();
            vod_sources.push(t0)
         }

        const result = {
            vod_actor,
            vod_area,
            vod_class,
            vod_content,
            vod_id,
            vod_lang,
            vod_name,
            vod_pic,
            vod_time,
            vod_year,
            vod_remarks,
            vod_sources,
            similar: similar(document)
        }
        return success(result)
    } catch (e) {
        console.error(e)
        return error(e.message);
    }
}

function similar(document) {
    try {
        const $list = select(document, "//ul[contains(@id, 'type')]/li")
        const list = []
        if ($list.length) {
            [].forEach.call($list ?? [], (node, i) => {
                const $link = select(node, ".//a[contains(@class, 'myui-vodlist__thumb')]")[0]
                if(!$link) return;
                const href = select($link, "./@href")[0]?.value
                const vod_name = select($link, "./@title")[0]?.value
                const pic_str = select($link, "./@style")[0]?.value
                const vod_remarks = select($link, "./span[contains(@class, 'pic-text')]//text()")?.toString()?.trim()

                const regex = /url\(\s*['"]?(.*?)['"]?\s*\)/i;
                const match = pic_str.match(regex);
                let vod_pic = ''
                if (match && match[1]) {
                    vod_pic = match[1]
                } 

                let vod_id;
                const matchVal = href.match(/\/vod\/(\d+)\.html/)
                if (matchVal) {
                    vod_id = matchVal[1]
                }
                if (vod_id) {
                    list.push({
                        vod_id: Number(vod_id),
                        vod_name,
                        vod_pic,
                        vod_remarks
                    })
                }
            })
        }
        return list
    } catch (e) {
        console.error(e)
        return []
    }

}

/**
 * 这里传入的是分集id, 不是视频id
 * @param {*} url  "/ep-449073-17-1.html"
 */
async function play({ url }) {
    try {
        const response = await request(`https://gimy.tv/${url}`)
        const notStandardHtml = await response.text();
        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);
        const document = new dom().parseFromString(html, 'text/html');
        const $script = select(document, ["//div[contains(@class, 'myui-player__video')]/script"])[0]
        let playUrl = ""
        if ($script) {
            const content = select($script, ".//text()")?.toString()?.trim();
            if (content.indexOf('var player_data=') !== -1) {
                const json = JSON.parse(content.substring(content.indexOf("{")));
                if (json && json.url) {
                    playUrl = json.url
                }
            }
        }

        return success(playUrl)
    } catch (e) {
        return error(e.message);
    }
}

async function list(type_id, page = 1) {
    try {
        const resposne = await request(config.list(type_id, page))
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();
        // fs.writeFileSync('./list.html', notStandardHtml)
        // const notStandardHtml = fs.readFileSync('./list.html', {encoding: 'utf8'})

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');
        
        const list = []
        const $sections = select(document, "//ul[contains(@class, 'myui-vodlist')]/li")
        $sections.forEach(($row) => {
            const $link = select($row, './/a[contains(@class, "thumb")]')?.[0]
            if (!$link) return
            const vod_name = select($link, "./@title")[0]?.value?.trim()
            const vod_remarks = select($link, "./span[contains(@class, 'pic-text')]//text()")?.toString()?.trim()
            const vod_pic = select($link, "./@data-original")[0]?.value?.trim()

            const href = select($link, "./@href")[0]?.value
            let vod_id;
            const matchVal = href.match(/\/vod\/(\d+)\.html/)
            if (matchVal) {
                vod_id = matchVal[1]
            }
            if (vod_id) {
                list.push({
                    vod_id: Number(vod_id),
                    vod_name,
                    vod_pic,
                    vod_remarks
                })
            }
        })

        const $pages = select(document, "//ul[contains(@class, 'myui-page')]")[0]
        let pages = 1;
        let total = 0;
        if ($pages) {
            const lastHref = select($pages, "./li[last()]/a/@href")[0]?.value
            if (lastHref) {
                const matchVal = lastHref.match(/(?=---(\d+)\.html$)/);
                if (matchVal) {
                    pages = Number(matchVal[1])
                    total = pages * $sections.length
                }
            }
        }
        return success({
            pages,
            page,
            list,
            total, // 模拟的数据，pages * items.length, 不一定真实
        })
    } catch (e) {
        console.error(e)
        return error(e.message);
    }
}

async function search(keyword, page = 1) {
    // 
    try {
        const resposne = await request(config.search(keyword, page))
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();
        // fs.writeFileSync('./search.html', notStandardHtml)
        // const notStandardHtml = fs.readFileSync('./search.html', {encoding: 'utf8'})

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');

        const list = []
        const $sections = select(document, "//ul[contains(@class, 'myui-vodlist')]/li")
        $sections.forEach(($row) => {
            const $link = select($row, './/a[contains(@class, "thumb")]')?.[0]
            if (!$link) return
            const vod_name = select($link, "./@title")[0]?.value?.trim()
            const vod_remarks = select($link, "./span[contains(@class, 'pic-text')]//text()")?.toString()?.trim()
            const vod_pic = select($link, "./@data-original")[0]?.value?.trim()

            const href = select($link, "./@href")[0]?.value
            let vod_id;
            const matchVal = href.match(/\/vod\/(\d+)\.html/)
            if (matchVal) {
                vod_id = matchVal[1]
            }
            if (vod_id) {
                list.push({
                    vod_id: Number(vod_id),
                    vod_name,
                    vod_pic,
                    vod_remarks
                })
            }
        })

        const $pages = select(document, "//ul[contains(@class, 'myui-page')]")[0]
        let pages = 1;
        let total = 0
        if ($pages) {
            const lastHref = select($pages, "./li[last()]/a/@href")[0]?.value
            if (lastHref) {
                const matchVal = lastHref.match(/(\d+)(?=---\.html$)/);
                if (matchVal) {
                    pages = Number(matchVal[1])
                    total = pages * $sections.length
                }
            }
        }

        return success({
            pages,
            page,
            list,
            total, // 模拟的数据，pages * items.length, 不一定真实
        })
    } catch (e) {
        console.error(e)
        return error(e.message);
    }
}

module.exports.home = home
module.exports.detail = detail
module.exports.play = play
module.exports.list = list
module.exports.search = search
