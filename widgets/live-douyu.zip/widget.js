const { CryptoJS, unescapeEntity } = require("./lib/index.js");
const { success, error } = require("./lib/response");
const { request } = require("./lib/request.js");

const direction = {
  horizontal: "horizontal",
  vertical: "vertical",
};

const isDev = typeof process !=='undefined';
function writeFile(filename, data) {
  if (isDev) {
    const fs = require("fs");
    fs.writeFileSync(`./.caches/${filename}`, data);
  }
}

/**
 * 通过home方法获取的接口，调用home方法后，就缓存
 */
const cateMap = {
  // 一级分类数据
  cate1Info: [],
  // 子分类数据
  cate2Info: [],
};

/**
 * 获取首页分类
 * @returns
 */
async function home() {
  try {
    const response = await request("https://m.douyu.com/api/cate/list");
    const json = await response.json();
    writeFile('home.json', JSON.stringify(json, null, 4))
    if (json.code !== 0 || !json.data) {
      throw new Error("获取接口出错");
    }
    cateMap.cate1Info = json.data.cate1Info;
    cateMap.cate2Info = json.data.cate2Info;
    // const categories = json.data.cate1Info.map((item) => ({
    //   type_id: item.cate1Id,
    //   type_name: item.cate1Name,
    //   vod_list: [],
    //   type_type: "other",
    // }));

    const categories = [
      {
          type_id: "9", type_name: "手游", vod_list: [], type_type: 'other',
      },
      {
          type_id: "1", type_name: "网游", vod_list: [], type_type: 'other',
      },
      {
          type_id: "15", type_name: "单机", vod_list: [], type_type: 'other',
      },
      {
          type_id: "2", type_name: "娱乐", vod_list: [], type_type: 'other',
      }
  ]

  return success(categories)
  } catch (e) {
    return error(e.message);
  }
}

/**
 * 根据home接口返回的数据获取对应的二级分类数据
 * @param {*} type_id 
 * @returns 
 */
async function cate(type_id) {
  try {
    const categories = cateMap.cate2Info.filter(item => item.cate1Id === Number(type_id)).map(item => ({
      type_id: item.cate2Id,
      type_name: item.cate2Name,
      vod_list: [],
    }))
    return success(categories);
  } catch (e) {
    console.log("cate fetcher error", e);
    return error(e.message);
  }
}

/**
 * 分类列表
 * @param {*} type_id
 * @param {*} page
 * @returns
 */
async function list(type_id, page = 1) {
  try {
    const response = await request(
      `https://www.douyu.com/gapi/rkc/directory/mixList/2_${type_id}/${page}`
    );
    const json = await response.json();
    writeFile("list.json", JSON.stringify(json, null, 4));
    if (json.code !== 0 || !json.data) {
      throw new Error("获取接口出错");
    }
    const rs = json.data;
    const items = [];

    const pages = rs.pgcnt;
    const list = rs?.rl ?? [];
    list.forEach((item) => {
      if (item.type === 1) {
        items.push({
          roomId: item.rid,
          vod_id: item.rid,
          vod_name: item.rn,
          vod_pic: item.rs16,
          vod_actor: item.nn,
          vod_avatar: `https://apic.douyucdn.cn/upload/${item.av}_big.jpg`,
          vod_blurb: item.authInfo.desc,
          online: item.ol,
          direction: direction.horizontal,
        });
      }
    });

    return success({
      pages,
      page,
      // 预估总数，不准确，用pages来做分页
      total: list.length * pages,
      list: items,
    });
  } catch (e) {
    return error(e.message);
  }
}

/**
 * 搜索
 * @param {*} keyword
 * @param {*} page
 * @param {*} pagesize
 * @returns
 */
async function search(keyword, page = 1, pagesize = 20) {
  try {
    const did = generateRandomString(32);
    const params = new URLSearchParams({
      kw: keyword,
      page: page,
      pageSize: 20,
    });
    const response = await request(
      `https://www.douyu.com/japi/search/api/searchShow?${params.toString()}`,
      {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.51",
          referer: "https://www.douyu.com/search/",
          Cookie: `dy_did=${did};acf_did=${did}`,
        },
      }
    );
    const json = await response.json();

    writeFile("search.json", JSON.stringify(json));
    if (json.error !== 0) {
      throw new Error(json.msg);
    }

    const items = [];
    (json?.data?.relateShow ?? []).forEach((item) => {
      items.push({
        roomId: item.rid,
        vod_id: item.rid,
        vod_name: item.roomName,
        vod_pic: item.roomSrc,
        vod_actor: item.nickName,
        vod_avatar: item.avatar,
        vod_blurb: item.description,
        direction: direction.horizontal,
      });
    });
    const pages = json?.data?.pageSize || 1;
    const total = json?.data?.total || 0;
    return success({
      page,
      pages,
      total,
      list: items,
    });
  } catch (e) {
    return error(e.message);
  }
}

/**
 * 获取直播间详情
 * @param {*} param0
 * @returns
 */
async function detail({ vod_id, roomId }) {
  try {
    const vid = vod_id || roomId
    if (!vid) throw new Error('参数错误')
    const roomInfo = await getRoomInfo(vid);

    const response = await request(
      `https://www.douyu.com/swf_api/homeH5Enc?rids=${vid}`,
      {
        headers: {
          referer: `https://www.douyu.com/${vid}`,
          "user-agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43",
        },
      }
    );

    const json = await response.json();
    writeFile(`detail_${vid}.json`, JSON.stringify(json, null, 4));

    const crptext = json.data[`room${vid}`];
    const plays = await getPlayArgs(crptext, roomInfo.room_id);

    const detail = {
      vod_pic: roomInfo.room_pic,
      online: Number(roomInfo.room_biz_all.hot),
      vod_id: roomInfo.room_id,
      vod_name: roomInfo.room_name,
      vod_actor: roomInfo.owner_name,
      vod_avatar: roomInfo.owner_avatar,
      vod_blurb: roomInfo.show_details || "",
      notice: "",
      status: roomInfo.show_status == 1 && roomInfo.videoLoop != 1,
      data: plays,
      vod_sources: [],
    };

    const qualities = await getPlayQualities(detail.vod_id, plays);


    for (let i = 0, len = qualities.length; i < len; i++) {
      const quality = qualities[i];
      const urls = await getPlayUrls(detail, quality);
      if (urls.length) {
        detail.vod_sources.push({
          source_name: quality.quality,
          vod_play_list: {
            // 兼容虎牙结构
            urls: [{
              name: quality.quality,
              urls
            }],
            url_count: urls.length,
          },
        });
      }
    }
    writeFile(
      `detail_${detail.vod_id}_done.json`,
      JSON.stringify(detail, null, 4)
    );
    return success(detail);
  } catch (e) {
    console.error(e);
    return error("detail => " + e.message);
  }
}

/**
 * 获取播放信息
 * @param {*} html
 * @param {*} rid
 * @returns
 */
async function getPlayArgs(html, rid) {
  //取加密的js
  let match = html.match(
    /(vdwdae325w_64we[\s\S]*function ub98484234[\s\S]*?)function/
  );
  html = match ? match[1] : "";
  html = html.replace(/eval.*?;}/g, "strc;}");
  const params = JSON.stringify({ html: html, rid: String(rid) });
  const response = await request(
    "http://alive.nsapps.cn/api/AllLive/DouyuSign",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // "Content-Length": params.length
      },
      body: params,
    }
  );
  const result = await response.json();
  writeFile(`play_${rid}.json`, JSON.stringify(result, null, 4));
  if (result.code === 0) {
    return result.data.toString();
  }
  return "";
}

/**
 * 获取房间信息
 * @param {*} id
 * @returns
 */
async function getRoomInfo(id) {
  const response = await request(`https://www.douyu.com/betard/${id}`, {
    headers: {
      referer: `https://www.douyu.com/${id}`,
      "user-agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43",
    },
  });

  const json = await response.json();
  writeFile(`room_${id}.json`, JSON.stringify(json, null, 4));

  return json?.room;
}

/**
 * 获取播放画质
 * @param {*} detail
 * @returns
 */
async function getPlayQualities(vod_id, playData) {
  const qualities = [];

  let data = playData;
  data += "&cdn=&rate=-1&ver=Douyu_223061205&iar=1&ive=1&hevc=0&fa=0";

  const response = await request(
    `https://www.douyu.com/lapi/live/getH5Play/${vod_id}`,
    {
      method: "POST",
      body: data,
      headers: {
        "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
      },
    }
  );

  const json = await response.json();
  writeFile(`quality_${detail.vod_id}.json`, JSON.stringify(json, null, 4));

  const cdns = [];
  (json.data.cdnsWithName ?? []).forEach((item) => {
    cdns.push(item.cdn);
  });

  // 如果cdn以scdn开头，将其放到最后
  cdns.sort((a, b) => {
    if (a.startsWith("scdn") && !b.startsWith("scdn")) {
      return 1;
    } else if (!a.startsWith("scdn") && b.startsWith("scdn")) {
      return -1;
    }
    return 0;
  });
  (json.data.multirates ?? []).forEach((item) => {
    qualities.push({
      quality: item.name,
      data: {
        rate: item.rate,
        cdns,
      },
    });
  });

  return qualities;
}

/**
 * 获取指定画质的播放地址
 * @param {*} detail
 * @param {*} quality
 * @returns
 */
async function getPlayUrls(detail, quality) {
  const args = detail.data;
  const data = quality.data;
  const urls = [];

  for (let i = 0, len = data.cdns.length; i < len; i++) {
    const item = data.cdns[i];
    const url = await getPlayUrl(detail.vod_id, args, data.rate, item);
    url && urls.push(url);
  }

  return urls;
}

/**
 * 获取对应cdn播放地址
 * @param {*} vod_id
 * @param {*} args
 * @param {*} rate
 * @param {*} cdn
 * @returns
 */
async function getPlayUrl(vod_id, args, rate, cdn) {
  const data = args + `&cdn=$${cdn}&rate=${rate}`;

  const response = await request(
    `https://www.douyu.com/lapi/live/getH5Play/${vod_id}`,
    {
      method: "POST",
      body: data,
      headers: {
        "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
        referer: `https://www.douyu.com/${vod_id}`,
        "user-agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36 Edg/114.0.1823.43",
      },
    }
  );

  const json = await response.json();
  return `${json.data.rtmp_url}/${unescapeEntity(json.data.rtmp_live)}`;
}

/**
 * 统一播放入口
 * @param {*} url
 * @returns
 */
async function play({ url }) {
  return Promise.resolve(success(url));
}

//生成指定长度的16进制随机字符串
function generateRandomString(length) {
  const randomBytes = CryptoJS.lib.WordArray.random(length / 2); // 生成随机字节
  return randomBytes.toString(CryptoJS.enc.Hex); // 转换为十六进制字符串
}

module.exports.home = home;
module.exports.cate = cate;
module.exports.list = list;
module.exports.search = search;
module.exports.detail = detail;
module.exports.play = play;
module.exports.room = getRoomInfo;
