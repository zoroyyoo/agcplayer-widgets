module.exports = {
    home: () => "https://www.wuwu0jc.wiki/index/home.html",
    list: (type_id, page) => `https://www.wuwu0jc.wiki/vodshow/${type_id}--------${page}---.html`,
    detail: (video_id)=> `https://www.wuwu0jc.wiki/voddetail/${video_id}.html`,
    play: (nid)=> `https://www.wuwu0jc.wiki/vodplay/${nid}.html`,
    search: (keyword, page)  => `https://www.wuwu0jc.wiki/vodsearch/${keyword}----------${page}---.html`
}