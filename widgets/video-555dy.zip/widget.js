const select = require('./lib/xpath.js')
const dom = require('./lib/xmldom/index.js').DOMParser
const parse5 = require('./lib/parse5.min.js')
const config = require('./config.js')
const { success, error } = require('./lib/response.js')
const { request } = require('./lib/request.js');
const { decryptUrl } = require('./decode.js')
const { unescapeEntity } = require('./lib/index.js')
// const fs = require('fs')

async function home() {
    try {
        const resposne = await request(config.home())
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();
        // fs.writeFileSync('./home.html', notStandardHtml)
        // const notStandardHtml = fs.readFileSync('./home.html', { encoding: 'utf8' })

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');
        const $container = select(document, "//div[contains(@class, 'main')]//div[contains(@class, 'content')]")[0]

        $sections = select($container, "./div[contains(@class, 'module')]")
        const result = []

        $sections.forEach(($row, i) => {
            const $header = select($row, "./div[contains(@class, 'module-heading')]")[0]

            const type_name = select($header, ".//h2[contains(@class, 'module-title')]//text()")?.toString()?.trim()

            const typeLink = select($row, ".//a[contains(@class, 'module-heading-more')]//@href")[0]?.value
            let type_id
            if (typeLink) {
                const matchVal = typeLink.match(/\/vodshow\/(\d+)-----------.html/)
                if (matchVal) {
                    type_id = matchVal[1]
                }
            }
            if (typeof type_id === 'undefined') return

            type_id = Number(type_id)

            const vod_list = []

            const $items = select($row, ".//a[contains(@class,'module-item')]")
            $items.forEach(($item, i) => {
                const href = select($item, "./@href")[0]?.value
                const vod_name = select($item, "./@title")[0]?.value
                const vod_pic = unescapeEntity(select($item, ".//div[contains(@class,'module-item-pic')]/img//@data-original")[0]?.value)
                const vod_remarks = select($item, ".//div[contains(@class, 'module-item-note')]//text()")?.toString()?.trim()
                let vod_id;
                const matchVal = href.match(/\/voddetail\/(\d+)\.html/)
                if (matchVal) {
                    vod_id = matchVal[1]
                }
                if (vod_id) {
                    vod_list.push({
                        type_id,
                        vod_id: Number(vod_id),
                        vod_name,
                        vod_pic,
                        vod_remarks
                    })
                }
            })
            if (vod_list.length) {
                result.push({
                    type_id,
                    type_name,
                    vod_list
                })
            }
        })
        return success(result);
    } catch (e) {
        console.error(e)
        return error(e.message);
    }

}

async function detail({ vod_id }) {
    try {
        const resposne = await request(config.detail(vod_id))
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();

        // fs.writeFileSync('./detail.html', notStandardHtml)
        // const notStandardHtml = fs.readFileSync('./detail.html', { encoding: 'utf8' })

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');
        const $container = select(document, "//div[contains(@class, 'main')]//div[contains(@class, 'content')]")[0]

        const $info = select($container, "//div[contains(@class, 'module-info')]")[0]

        let vod_actor = ''
        let vod_area = ''
        let vod_class = ''
        let vod_lang = ''
        let vod_time = ''
        let vod_year = ''
        let vod_remarks = ''

        let vod_name = "";
        let vod_pic = "";
        let vod_content = "";

        const vod_sources = []

        if ($info) {
            const actor_label = "主演"
            const time_label = "更新"
            const remarks_label = ["连载", "备注", "片长"]

            vod_name = (select($info, ".//div[contains(@class, 'module-info-heading')]/h1/text()") || "").toString().trim();
            vod_pic = unescapeEntity(select($info, ".//div[contains(@class, 'module-info-poster')]//img/@data-original")[0]?.value)

            const $tags = select($info, ".//div[contains(@class, 'module-info-tag')]/div[contains(@class, 'module-info-tag-link')]")
            $tags.forEach(($tag, i) => {
                const $links = select($tag, "./a")
                switch (i) {
                    case 0:
                        vod_year = select($links[0], './text()')?.toString()?.trim()
                        break;
                    case 1:
                        vod_area = select($links[0], './text()')?.toString()?.trim();
                        break;
                    case 2:
                        const classList = [];
                        $links.forEach((link, i) => {
                            const type = select(link, "./text()")?.toString()?.trim();
                            type && classList.push(type)
                        })

                        vod_class = classList.join(',')
                        break;
                }
            })
            const $content = select($info, ".//div[contains(@class, 'module-info-content')]")[0]
            if ($content) {
                vod_content = select($content, ".//div[contains(@class, 'module-info-introduction-content')]/p/text()")?.toString()?.trim();

                const $rows = select($content, ".//div[contains(@class, 'module-info-item')]")
                $rows.forEach(($row, i) => {
                    // 跳过简介
                    if (i === 0) return;
                    const label = (select($row, "./span[contains(@class, 'module-info-item-title')]/text()")?.toString()?.trim() || '').replace('：', '');
                    const $cont = select($row, "./div[contains(@class, 'module-info-item-content')]")[0]
                    if (!$cont) return
                    const content = select($cont, ".//text()")?.toString()?.trim();
                    if (label.includes(actor_label)) {
                        const actors = [];
                        const $links = select($cont, "./a")
                        $links.forEach((link, i) => {
                            const actor = select(link, "./text()")?.toString()?.trim();
                            actor && actors.push(actor)
                        })

                        vod_actor = actors.join(',')
                    } else if (label.includes(time_label)) {
                        if (content) {
                            vod_time = content
                            // const date = new Date(content)
                            // if (date !== 'Invalid Date') {
                            //     vod_time = parseInt(date.getTime() / 1000);
                            // }
                        }
                    } else if (remarks_label.includes(label)) {
                        vod_remarks = content
                    }
                })
            }
        }

        const $sources = select($container, "//div[contains(@class, 'player-heading')]//parent::*")[0]
        const $tabs = select($sources, ".//div[contains(@class, 'module-tab-items-box')]/div[contains(@class, 'module-tab-item')]")
        const $linkList = select($sources, "./div[contains(@class, 'his-tab-list')]")

        $tabs.forEach(($tab, i) => {
            const source_name = select($tab, "./span/text()").toString()?.trim()
            const source_count = select($tab, "./small/text()").toString()?.trim()

            if ($linkList[i] && source_name) {
                const source = {
                    source_name: source_name,
                    vod_play_list: {
                        url_count: 0,
                        urls: []
                    }
                }
                const $links = select($linkList[i], ".//a[contains(@class, 'module-play-list-link')]")

                $links.forEach($link => {
                    const url = {
                        name: '',
                        url: '',
                    }
                    const href = select($link, "./@href")[0]?.value?.trim();
                    const name = select($link, './span/text()')?.toString()?.trim();
                    url.name = name
                    url.url = href
                    source.vod_play_list.urls.push(url);
                })
                source.vod_play_list.url_count = source.vod_play_list.urls.length
                vod_sources.push(source)
            }
        })

        const result = {
            vod_actor,
            vod_area,
            vod_class,
            vod_content,
            vod_id,
            vod_lang,
            vod_name,
            vod_pic,
            vod_time,
            vod_year,
            vod_remarks,
            vod_sources,
            similar: similar($container)
        }
        return success(result)
    } catch (e) {
        console.error(e)
        return error(e.message);
    }
}

function similar(document) {
    try {
        const $list = select(document, ".//div[contains(@class, 'module-poster-items-base')]/a[contains(@class, 'module-poster-item')]")
        const list = []
        if ($list.length) {
            [].forEach.call($list ?? [], (node, i) => {
                const vod_pic = unescapeEntity(select(node, ".//img/@data-original")[0]?.value)
                const vod_name = select(node, "./@title")[0]?.value

                const href = select(node, "./@href")[0]?.value

                let vod_id;
                const matchVal = href.match(/\/voddetail\/(\d+)\.html/)
                if (matchVal) {
                    vod_id = matchVal[1]
                }

                const vod_remarks = select(node, ".//div[contains(@class, 'module-item-note')]/text()")?.toString()?.trim()

                list.push({
                    vod_id: Number(vod_id),
                    vod_pic,
                    vod_name,
                    vod_remarks
                })

            })
        }
        return list
    } catch (e) {
        return []
    }

}

/**
 * 这里传入的是分集id, 不是视频id
 * @param {*} url  "/vodplay/449073-17-1.html"
 */
async function getPlayUrl({url}) {
    try {
        const matchVal = url.match(/\/vodplay\/(\d+-\d+-\d+)\.html/)

        if (!matchVal) {
            throw new Error(`参数错误：${url}`)

        }
        const val = matchVal[1]
        const arr = val.split('-');
        if (arr.length !== 3) {
            throw new Error(`参数错误：${url}`)
        }
        const [id, sid, nid] = arr

        const response = await request(`https://www.wuwu0jc.wiki/voddisp/id/${id}/sid/${sid}/nid/${nid}.html`)
        const json = await response.json();
        if (!json?.url) {
            throw new Error(`获取播放地址失败：${JSON.stringify(json)}`)
        }

        const playUrl = decryptUrl(json.url)

        return success(playUrl)
    } catch (e) {
        return error(e.message);
    }
}

async function list(type_id, page = 1) {
    try {
        const resposne = await request(config.list(type_id, page))
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();
        // fs.writeFileSync('./list.html', notStandardHtml)
        // const notStandardHtml = fs.readFileSync('./list.html', {encoding: 'utf8'})

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');

        const $container = select(document, "//div[contains(@class, 'module-page')]")[0]
        const list = []
        const $sections = select($container, ".//a[contains(@class, 'module-poster-item')]")
        $sections.forEach(($row) => {
            const vod_name = select($row, "./@title")[0]?.value
            const vod_remarks = select($row, ".//div[contains(@class, 'module-item-note')]//text()")?.toString()?.trim()
            const vod_pic = unescapeEntity(select($row, ".//div[contains(@class,'module-item-pic')]/img//@data-original")[0]?.value)

            const href = select($row, "./@href")[0]?.value
            let vod_id;
            const matchVal = href.match(/\/voddetail\/(\d+)\.html/)
            if (matchVal) {
                vod_id = matchVal[1]
            }
            if (vod_id) {
                list.push({
                    vod_id: Number(vod_id),
                    vod_name,
                    vod_pic,
                    vod_remarks
                })
            }
        })

        let pages = 1

        const $pages = select(document, "//div[@id='page']")[0]

        if ($pages) {
            const lastHref = select($pages, "(./a[contains(@class, 'page-next')])[last()]/@href")[0]?.value
            if (lastHref) {
                const matchVal = lastHref.match(/(\d+)(?=---\.html$)/);
                if (matchVal) {
                    pages = Number(matchVal[1])
                }
            }
        }
        return success({
            pages,
            page,
            list,
        })
    } catch (e) {
        console.error(e)
        return error(e.message);
    }
}

async function search(keyword, page = 1) {
    try {
        const resposne = await request(config.search(keyword, page))
        if (resposne.status !== 200) throw new Error(`NetWork Error, Status: ${resposne.status}`);
        const notStandardHtml = await resposne.text();
        // fs.writeFileSync('./search.html', notStandardHtml)
        // const notStandardHtml = fs.readFileSync('./search.html', {encoding: 'utf8'})

        // 不标准的html结构，目前使用parse5格式化一下在转回标准html；
        const doc5 = parse5.parseFragment(notStandardHtml);
        const html = parse5.serialize(doc5);

        const document = new dom().parseFromString(html, 'text/html');

        const $container = select(document, "//div[contains(@class, 'module-page')]")[0]
        const list = []

        const $sections = select($container, "./div[contains(@class, 'module-card-items')]/div[contains(@class, 'module-card-item')]")
        $sections.forEach(($row) => {
            const $link = select($row, './/a[contains(@class, "module-card-item-poster")]')?.[0]
            if (!$link) return
            const vod_name = select($row, ".//div[contains(@class, 'module-card-item-title')]//strong/text()")?.toString()?.trim()
            const vod_remarks = select($link, ".//div[contains(@class, 'module-item-note')]//text()")?.toString()?.trim()
            const vod_pic = unescapeEntity(select($link, ".//div[contains(@class,'module-item-pic')]/img//@data-original")[0]?.value)

            const href = select($link, "./@href")[0]?.value
            let vod_id;
            const matchVal = href.match(/\/voddetail\/(\d+)\.html/)
            if (matchVal) {
                vod_id = matchVal[1]
            }
            if (vod_id) {
                list.push({
                    vod_id: Number(vod_id),
                    vod_name,
                    vod_pic,
                    vod_remarks
                })
            }
        })

        const $pages = select(document, "//div[@id='page']")[0]
        let pages = 1;
        if ($pages) {
            const lastHref = select($pages, "(./a[contains(@class, 'page-next')])[last()]/@href")[0]?.value
            if (lastHref) {
                const matchVal = lastHref.match(/(\d+)(?=---\.html$)/);
                if (matchVal) {
                    pages = Number(matchVal[1])
                }
            }
        }

        return success({
            pages,
            page,
            list,
        })
    } catch (e) {
        console.error(e)
        return error(e.message);
    }
}

module.exports.home = home
module.exports.detail = detail
module.exports.play = getPlayUrl
module.exports.list = list
module.exports.search = search
