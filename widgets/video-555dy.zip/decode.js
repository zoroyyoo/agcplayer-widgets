
const CryptoJS = require('./lib/polyfill/crypto-js/index.js')

// const fetch_url = "https://www.wuwu0jc.wiki/voddisp/id/515079/sid/4/nid/3.html"
const key1 = "81f834a7f68d4c52";
const key2 = 'zkz8scsGXttFVZBb'

module.exports.decryptUrl = function(url) {
    const text = url.replace(/O0O0O/g, '=').replace(/o000o/g, '+').replace(/oo00o/g, '/');
    const base64 = CryptoJS.enc.Base64.parse(text)

    const str1 = CryptoJS.enc.Utf8.parse(key1)
    const iv = CryptoJS.enc.Utf8.parse(key2)

    const aes = CryptoJS.AES.decrypt({
        ciphertext: base64
    }, str1,
        {
            iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        }
    )
    const rs = aes.toString(CryptoJS.enc.Utf8)
    return rs
}